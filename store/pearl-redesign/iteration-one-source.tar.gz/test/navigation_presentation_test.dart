import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/dev/preview_fixtures.dart';
void main(){
 Future<void> start(WidgetTester tester)async{
  tester.view.physicalSize=const Size(393,852);tester.view.devicePixelRatio=1;addTearDown((){tester.view.resetPhysicalSize();tester.view.resetDevicePixelRatio();});
  final fixture=PreviewFixture('learn');
  await tester.pumpWidget(ProviderScope(overrides:fixture.overrides,child:MaterialApp(theme:buildAppTheme(),builder:(context,child)=>MediaQuery(data:MediaQuery.of(context).copyWith(disableAnimations:true),child:BlushBackdrop(child:child!)),home:fixture.build())));await tester.pumpAndSettle();
 }
 testWidgets('only user vertical scrolling minimizes navigation and upward scrolling expands it',(tester)async{
  await start(tester);expect(find.text('Learn'),findsOneWidget);
  final scroll=find.byType(CustomScrollView).first;
  final controller=PrimaryScrollController.of(tester.element(scroll));
  controller.jumpTo(240);await tester.pumpAndSettle();expect(find.text('Learn'),findsOneWidget,reason:'Programmatic movement must keep navigation expanded');
  await tester.drag(scroll,const Offset(0,-160));await tester.pumpAndSettle();expect(find.text('Learn'),findsNothing);
  await tester.drag(scroll,const Offset(0,120));await tester.pumpAndSettle();expect(find.text('Learn'),findsOneWidget);
  expect(tester.takeException(),isNull);
 });
 testWidgets('Saved search survives tab changes and reselecting Learn returns to the top',(tester)async{
  await start(tester);await tester.tap(find.text('Saved'));await tester.pumpAndSettle();
  await tester.enterText(find.byType(TextField).first,'kept words');await tester.pumpAndSettle();
  await tester.tap(find.text('Profile').first);await tester.pumpAndSettle();await tester.tap(find.text('Saved').first);await tester.pumpAndSettle();
  expect(find.text('kept words'),findsOneWidget);
  await tester.tap(find.text('Learn'));await tester.pumpAndSettle();
  final scroll=find.byType(CustomScrollView).first,controller=PrimaryScrollController.of(tester.element(find.byType(CustomScrollView).first));
  controller.jumpTo(600);await tester.pumpAndSettle();await tester.tap(find.text('Learn'));await tester.pumpAndSettle();expect(controller.offset,0);
  expect(scroll,findsOneWidget);expect(tester.takeException(),isNull);
 });
}
