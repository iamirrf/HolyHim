import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/data/lessons.dart';

/// A physical foreground plane: a lit upper edge, a rose underside and two
/// different shadow distances. Only featured objects use this material.
class PearlSurface extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius, lift;
  final bool ribbon;
  const PearlSurface(
      {super.key,
      required this.child,
      this.padding = EdgeInsets.zero,
      this.radius = 24,
      this.lift = 0,
      this.ribbon = false});
  @override
  Widget build(BuildContext context) => DecoratedBox(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          boxShadow: [
            BoxShadow(
                color: AppColors.accentDark.withValues(alpha: .06 + lift * .05),
                blurRadius: 32 + lift * 18,
                offset: Offset(0, 16 + lift * 8)),
            BoxShadow(
                color: AppColors.accentDark.withValues(alpha: .07),
                blurRadius: 3,
                offset: const Offset(0, 3)),
            const BoxShadow(
                color: Colors.white, blurRadius: 1, offset: Offset(0, -1)),
          ]),
      child: ClipRRect(
          borderRadius: BorderRadius.circular(radius),
          child: DecoratedBox(
              decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      begin: Alignment(-.8, -1),
                      end: Alignment(1, .8),
                      colors: [
                        Colors.white,
                        Color(0xFFFFFDFE),
                        Color(0xFFF7E8EF)
                      ],
                      stops: [
                        0,
                        .68,
                        1
                      ]),
                  borderRadius: BorderRadius.circular(radius),
                  border: Border.all(color: Colors.white, width: 1.3)),
              child: Stack(children: [
                if (ribbon)
                  const Positioned(top: 0, right: 28, child: RibbonDetail()),
                Padding(padding: padding, child: child),
              ]))));
}

class QuietInset extends StatelessWidget {
  final Widget child;
  final bool selected;
  final EdgeInsetsGeometry padding;
  const QuietInset(
      {super.key,
      required this.child,
      this.selected = false,
      this.padding = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context) => AnimatedContainer(
      duration: MediaQuery.disableAnimationsOf(context)
          ? Duration.zero
          : const Duration(milliseconds: 200),
      padding: padding,
      decoration: BoxDecoration(
          color: selected
              ? AppColors.surface
              : Colors.white.withValues(alpha: .86),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: selected ? AppColors.accent : AppColors.divider,
              width: selected ? 1.5 : 1)),
      child: child);
}

class RibbonDetail extends StatelessWidget {
  final double height;
  const RibbonDetail({super.key, this.height = 42});
  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size(18, height), painter: _RibbonPainter());
}

class _RibbonPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final p = Path()
      ..lineTo(s.width, 0)
      ..lineTo(s.width, s.height)
      ..lineTo(s.width / 2, s.height - 7)
      ..lineTo(0, s.height)
      ..close();
    canvas.drawPath(
        p,
        Paint()
          ..shader = const LinearGradient(colors: [
            AppColors.accentDark,
            AppColors.accent,
            Color(0xFFB67191)
          ]).createShader(Offset.zero & s));
    canvas.drawLine(
        const Offset(3, 0),
        Offset(3, s.height - 3),
        Paint()
          ..color = Colors.white.withValues(alpha: .35)
          ..strokeWidth = .7);
  }

  @override
  bool shouldRepaint(_RibbonPainter old) => false;
}

class ScripturePage extends StatelessWidget {
  final DailyLesson lesson;
  final bool compact, saved;
  const ScripturePage(
      {super.key,
      required this.lesson,
      this.compact = false,
      this.saved = false});
  @override
  Widget build(BuildContext context) => PearlSurface(
      ribbon: saved,
      padding:
          EdgeInsets.fromLTRB(compact ? 24 : 32, 28, compact ? 24 : 32, 32),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
                'DAY ${lesson.day.toString().padLeft(2, '0')}  /  ${saved ? 'KEPT CLOSE' : 'SCRIPTURE'}',
                style: HolyTypography.label
                    .copyWith(color: AppColors.accent, letterSpacing: 1.2)),
            const SizedBox(height: 24),
            Text(lesson.verseText,
                style: HolyTypography.scripture
                    .copyWith(color: AppColors.textPrimary)),
            const SizedBox(height: 24),
            Container(
                height: 1,
                width: 32,
                color: AppColors.accent.withValues(alpha: .45)),
            const SizedBox(height: 16),
            Text(lesson.verseReference,
                style: HolyTypography.supporting
                    .copyWith(color: AppColors.accentDark)),
            const SizedBox(height: 4),
            Text('World English Bible',
                style: HolyTypography.supporting
                    .copyWith(color: AppColors.textSecondary)),
          ]));
}

class LessonMiniature extends StatelessWidget {
  final DailyLesson lesson;
  const LessonMiniature({super.key, required this.lesson});
  @override
  Widget build(BuildContext context) => PearlSurface(
      padding: const EdgeInsets.all(20),
      child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('DAY ${lesson.day.toString().padLeft(2, '0')}',
                style: HolyTypography.label
                    .copyWith(color: AppColors.accent, letterSpacing: 1.4)),
            const SizedBox(height: 16),
            const Icon(Icons.menu_book_outlined,
                size: 28, color: AppColors.accent),
            const SizedBox(height: 16),
            Text(lesson.title, style: HolyTypography.section),
            const SizedBox(height: 12),
            Text(lesson.verseReference,
                style: HolyTypography.supporting
                    .copyWith(color: AppColors.textSecondary)),
          ]));
}

enum LessonNodeState { current, available, inProgress, complete, future }

class LessonMedallion extends StatelessWidget {
  final LessonNodeState state;
  final double progress;
  const LessonMedallion({super.key, required this.state, this.progress = 0});
  @override
  Widget build(BuildContext context) {
    final current =
        state == LessonNodeState.current || state == LessonNodeState.inProgress;
    final done = state == LessonNodeState.complete;
    return SizedBox.square(
        dimension: 104,
        child: Stack(alignment: Alignment.center, children: [
          if (current)
            Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(colors: [
                      AppColors.surfaceLight.withValues(alpha: .85),
                      AppColors.surface.withValues(alpha: 0)
                    ]))),
          if (current)
            SizedBox.square(
                dimension: 98,
                child: CircularProgressIndicator(
                    value: progress == 0 ? 1 : progress,
                    strokeWidth: 1.5,
                    color: AppColors.accent.withValues(alpha: .7),
                    backgroundColor: AppColors.divider)),
          Transform.translate(
              offset: const Offset(0, 7),
              child: Container(
                  width: 74,
                  height: 74,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color:
                          done ? AppColors.accentDark : AppColors.surfaceLight,
                      boxShadow: [
                        BoxShadow(
                            color: AppColors.accentDark.withValues(alpha: .14),
                            blurRadius: 12,
                            offset: const Offset(0, 6))
                      ]))),
          Container(
              width: 74,
              height: 74,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: done
                          ? [const Color(0xFFB36D8D), AppColors.accent]
                          : state == LessonNodeState.future
                              ? [
                                  const Color(0xFFF7EDF2),
                                  const Color(0xFFEBDDE5)
                                ]
                              : [
                                  Colors.white,
                                  const Color(0xFFFFFDFE),
                                  AppColors.surface
                                ]),
                  border: Border.all(
                      color: current
                          ? AppColors.accent.withValues(alpha: .65)
                          : Colors.white,
                      width: 1.5)),
              child: Icon(
                  done
                      ? Icons.check_rounded
                      : state == LessonNodeState.future
                          ? Icons.lock_outline_rounded
                          : state == LessonNodeState.inProgress
                              ? Icons.play_arrow_rounded
                              : Icons.menu_book_outlined,
                  size: 34,
                  color: done
                      ? Colors.white
                      : state == LessonNodeState.future
                          ? AppColors.textSecondary
                          : AppColors.accent)),
          Positioned(
              top: 17,
              child: Container(
                  width: 34,
                  height: 2,
                  decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .8),
                      borderRadius: BorderRadius.circular(2)))),
        ]));
  }
}

class RoseRoutePainter extends CustomPainter {
  final List<Offset> points;
  final int completed;
  final Set<int>? completedSegments;
  const RoseRoutePainter(
      {required this.points, this.completed = 0, this.completedSegments});
  @override
  void paint(Canvas canvas, Size size) {
    for (var i = 0; i < points.length - 1; i++) {
      final a = Offset(points[i].dx * size.width, points[i].dy),
          b = Offset(points[i + 1].dx * size.width, points[i + 1].dy);
      final path = Path()
        ..moveTo(a.dx, a.dy)
        ..cubicTo(a.dx, a.dy + (b.dy - a.dy) * .56, b.dx,
            b.dy - (b.dy - a.dy) * .56, b.dx, b.dy);
      canvas.drawPath(
          path,
          Paint()
            ..color = AppColors.divider
            ..strokeWidth = 9
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round);
      canvas.drawPath(
          path,
          Paint()
            ..color = Colors.white.withValues(alpha: .7)
            ..strokeWidth = 2
            ..style = PaintingStyle.stroke);
      if (completedSegments?.contains(i) ?? (i < completed)) {
        canvas.drawPath(
            path,
            Paint()
              ..color = AppColors.accent.withValues(alpha: .12)
              ..strokeWidth = 15
              ..style = PaintingStyle.stroke
              ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7));
        canvas.drawPath(
            path,
            Paint()
              ..color = AppColors.accent
              ..strokeWidth = 6.5
              ..style = PaintingStyle.stroke
              ..strokeCap = StrokeCap.round);
      }
    }
  }

  @override
  bool shouldRepaint(RoseRoutePainter old) =>
      old.completed != completed ||
      old.points != points ||
      old.completedSegments != completedSegments;
}

class CompletionOrbit extends StatelessWidget {
  final Animation<double> animation;
  final bool accepted;
  const CompletionOrbit(
      {super.key, required this.animation, required this.accepted});
  @override
  Widget build(BuildContext context) => SizedBox.square(
      dimension: 180,
      child: AnimatedBuilder(
          animation: animation,
          builder: (context, _) => CustomPaint(
              painter: _OrbitPainter(accepted ? animation.value : 0,
                  MediaQuery.disableAnimationsOf(context)),
              child: Center(
                  child: Container(
                      width: 80,
                      height: 80,
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                              colors: [Colors.white, AppColors.surface])),
                      child: Icon(
                          accepted
                              ? Icons.check_rounded
                              : Icons.cloud_upload_outlined,
                          size: 38,
                          color: AppColors.accent))))));
}

class _OrbitPainter extends CustomPainter {
  final double t;
  final bool reduced;
  const _OrbitPainter(this.t, this.reduced);
  @override
  void paint(Canvas c, Size s) {
    final center = s.center(Offset.zero), settle = math.sin(t * math.pi).abs();
    final paint = Paint()
      ..color = const Color(0xFFE6BE9C).withValues(alpha: .14 + settle * .18)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18);
    c.drawCircle(center, 46 + 15 * settle, paint);
    c.drawCircle(
        center,
        52,
        Paint()
          ..color = AppColors.divider
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1);
    if (reduced || t == 0 || t >= 1) return;
    for (final angle in [-.5, .5]) {
      c.save();
      c.translate(center.dx, center.dy);
      c.rotate(angle + t * .5);
      c.drawOval(
          Rect.fromCenter(center: Offset.zero, width: 156, height: 38),
          Paint()
            ..color = const Color(0xFFE5BD9C).withValues(alpha: settle * .28)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.4);
      c.restore();
    }
    final random = math.Random(31);
    for (var i = 0; i < 18; i++) {
      final a =
          random.nextDouble() * math.pi * 2 + math.min(t / .8, 1) * math.pi * 2;
      final radius = 55 + random.nextDouble() * 26;
      c.drawCircle(
          center + Offset(math.cos(a), math.sin(a)) * radius,
          1 + random.nextDouble() * 1.4,
          Paint()
            ..color = const Color(0xFFBD8B64).withValues(alpha: settle * .7));
    }
  }

  @override
  bool shouldRepaint(_OrbitPainter old) => old.t != t || old.reduced != reduced;
}
