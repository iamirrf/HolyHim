import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/widgets/holy_material.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/services/streak_service.dart';

/// Shared fading tint adapted from AppTopBar's .70/.58/.38/.16/0 ramp.
class HolyHeader extends ConsumerWidget {
  final VoidCallback onProgress;
  const HolyHeader({super.key, required this.onProgress});
  @override
  Widget build(BuildContext context, WidgetRef ref) => HolyFadingMaterial(
      child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 16, 12),
          child: Row(children: [
            const HolyMark(size: 36),
            const SizedBox(width: 10),
            const Expanded(
                child: Text('HolyHer',
                    style:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.w600))),
            TextButton.icon(
                onPressed: onProgress,
                icon: const Icon(Icons.local_fire_department_outlined),
                label: Text('${ref.watch(streakProvider).current}'))
          ])));
}
