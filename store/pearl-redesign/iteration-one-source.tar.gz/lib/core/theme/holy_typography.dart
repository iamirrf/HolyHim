import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// iOS resolves SF Rounded through UIKit. Font data lives only in process memory;
/// no Apple font is packaged with the application or written to disk.
abstract final class HolyTypography {
  static const family = 'HolyHerSystemRounded';
  static const channel = MethodChannel('holyher/typography');
  static Map<String, dynamic>? nativeResolution;
  static Future<void> initialize() async {
    if (!Platform.isIOS) return;
    final result = await channel.invokeMapMethod<String, dynamic>('resolve');
    if (result == null) {
      throw StateError('Rounded typography was not resolved.');
    }
    final loader = FontLoader(family);
    for (final weight in ['regular', 'semibold']) {
      final bytes = result[weight] as Uint8List;
      loader.addFont(Future.value(ByteData.sublistView(bytes)));
    }
    await loader.load();
    nativeResolution = Map.of(result)
      ..remove('regular')
      ..remove('semibold');
    for (final entry in [
      ('regular', FontWeight.w400),
      ('semibold', FontWeight.w600)
    ]) {
      final painter = TextPainter(
          text: TextSpan(
              text: 'A moment with God. 0123456789',
              style: TextStyle(
                  fontFamily: family, fontSize: 22, fontWeight: entry.$2)),
          textDirection: TextDirection.ltr)
        ..layout();
      nativeResolution!['${entry.$1}FlutterWidth'] = painter.width;
      final delta = (painter.width - (result['${entry.$1}Width'] as num)).abs();
      nativeResolution!['${entry.$1}WidthDelta'] = delta;
      if (delta > .05) {
        throw StateError('Rounded font metrics differ from UIKit.');
      }
    }
  }

  static const display = TextStyle(
      fontFamily: family,
      fontSize: 34,
      height: 39 / 34,
      fontWeight: FontWeight.w600,
      letterSpacing: -.7);
  static const heading = TextStyle(
      fontFamily: family,
      fontSize: 28,
      height: 33 / 28,
      fontWeight: FontWeight.w600,
      letterSpacing: -.4);
  static const section = TextStyle(
      fontFamily: family,
      fontSize: 22,
      height: 27 / 22,
      fontWeight: FontWeight.w600);
  static const scripture = TextStyle(
      fontFamily: family,
      fontSize: 22,
      height: 32 / 22,
      fontWeight: FontWeight.w400);
  static const reading = TextStyle(
      fontFamily: family,
      fontSize: 20,
      height: 1.5,
      fontWeight: FontWeight.w400);
  static const body = TextStyle(
      fontFamily: family,
      fontSize: 17,
      height: 25 / 17,
      fontWeight: FontWeight.w400);
  static const action = TextStyle(
      fontFamily: family,
      fontSize: 17,
      height: 22 / 17,
      fontWeight: FontWeight.w600);
  static const supporting = TextStyle(
      fontFamily: family,
      fontSize: 14,
      height: 20 / 14,
      fontWeight: FontWeight.w400);
  static const label = TextStyle(
      fontFamily: family,
      fontSize: 12,
      height: 16 / 12,
      fontFeatures: [FontFeature.tabularFigures()],
      fontWeight: FontWeight.w600);
}
