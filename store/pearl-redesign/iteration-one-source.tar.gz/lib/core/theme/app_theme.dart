import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:holyher/core/theme/holy_typography.dart';
export 'package:holyher/core/theme/holy_typography.dart';

abstract final class AppColors {
  static const background = Color(0xFFFFF9FB);
  static const pearl = Colors.white;
  static const surface = Color(0xFFF9E5ED);
  static const surfaceLight = Color(0xFFF2D0DF);
  static const accent = Color(0xFF9C456B);
  static const accentDark = Color(0xFF64243F);
  static const textPrimary = Color(0xFF382331);
  static const textSecondary = Color(0xFF735867);
  static const divider = Color(0xFFE9D4DF);
  static const flame = Color(0xFFAC542F);
  static const success = Color(0xFF397064);
  static const error = Color(0xFF9C263B);
}

ThemeData buildAppTheme() {
  final text = const TextTheme(
    displayLarge: HolyTypography.display,
    displayMedium: HolyTypography.display,
    displaySmall: HolyTypography.heading,
    headlineLarge: HolyTypography.display,
    headlineMedium: HolyTypography.heading,
    headlineSmall: HolyTypography.section,
    titleLarge: HolyTypography.section,
    titleMedium: HolyTypography.action,
    titleSmall: HolyTypography.label,
    bodyLarge: HolyTypography.body,
    bodyMedium: HolyTypography.body,
    bodySmall: HolyTypography.supporting,
    labelLarge: HolyTypography.action,
    labelMedium: HolyTypography.label,
    labelSmall: HolyTypography.label,
  ).apply(
      bodyColor: AppColors.textPrimary, displayColor: AppColors.textPrimary);
  final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(18),
      borderSide: const BorderSide(color: AppColors.textSecondary));
  return ThemeData(
    useMaterial3: true,
    fontFamily: HolyTypography.family,
    textTheme: text,
    scaffoldBackgroundColor: Colors.transparent,
    brightness: Brightness.light,
    colorScheme: const ColorScheme.light(
        primary: AppColors.accent,
        onPrimary: Colors.white,
        surface: AppColors.background,
        onSurface: AppColors.textPrimary,
        secondary: AppColors.textSecondary,
        outline: AppColors.textSecondary,
        error: AppColors.error),
    appBarTheme: const AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        foregroundColor: AppColors.textPrimary,
        titleTextStyle: TextStyle(
            fontFamily: HolyTypography.family,
            fontSize: 17,
            height: 22 / 17,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary),
        systemOverlayStyle: SystemUiOverlayStyle.dark),
    inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white.withValues(alpha: .88),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
        border: border,
        enabledBorder: border.copyWith(
            borderSide: const BorderSide(color: AppColors.divider)),
        focusedBorder: border.copyWith(
            borderSide: const BorderSide(color: AppColors.accent, width: 1.5)),
        errorMaxLines: 3,
        helperMaxLines: 3,
        labelStyle: HolyTypography.body,
        helperStyle: HolyTypography.supporting),
    textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
            textStyle: HolyTypography.action, minimumSize: const Size(44, 44))),
    filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
            textStyle: HolyTypography.action, minimumSize: const Size(44, 56))),
    outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
            textStyle: HolyTypography.body,
            minimumSize: const Size(44, 44),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)))),
    chipTheme: ChipThemeData(
        labelStyle: HolyTypography.supporting,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
    bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.background,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)))),
    dialogTheme: DialogThemeData(
        backgroundColor: AppColors.pearl,
        titleTextStyle:
            HolyTypography.section.copyWith(color: AppColors.textPrimary),
        contentTextStyle:
            HolyTypography.body.copyWith(color: AppColors.textPrimary),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28))),
    snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.textPrimary,
        contentTextStyle:
            HolyTypography.supporting.copyWith(color: Colors.white),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    dividerTheme:
        const DividerThemeData(color: AppColors.divider, thickness: 1),
    progressIndicatorTheme:
        const ProgressIndicatorThemeData(color: AppColors.accent),
    textSelectionTheme: TextSelectionThemeData(
        cursorColor: AppColors.accent,
        selectionColor: AppColors.accent.withValues(alpha: .18)),
  );
}
