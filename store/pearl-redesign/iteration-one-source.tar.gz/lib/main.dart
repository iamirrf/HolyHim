import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/constants/app_constants.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/features/home/home_shell.dart';
import 'package:holyher/features/landing/landing_screen.dart';
import 'package:holyher/features/onboarding/onboarding_screen.dart';
import 'package:holyher/features/splash/splash_screen.dart';
import 'package:holyher/firebase_options.dart';
import 'package:holyher/services/auth_service.dart';
import 'package:holyher/services/profile_service.dart';
import 'package:holyher/services/progress_service.dart';
import 'package:holyher/services/streak_service.dart';
import 'package:holyher/services/reminder_service.dart';
import 'package:holyher/services/learning_service.dart';
import 'package:holyher/services/saved_service.dart';
import 'package:holyher/features/lesson/lesson_screen.dart';
import 'package:holyher/data/lessons.dart';
import 'package:holyher/core/widgets/holy_ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await HolyTypography.initialize();
  } catch (_) {
    runApp(ProviderScope(
        child: MaterialApp(
            theme: buildAppTheme(),
            home: const HolyRecovery(
                message: 'We could not prepare HolyHer. Please retry.',
                onRetry: main))));
    return;
  }
  try {
    await Firebase.initializeApp(options: HolyHerFirebaseOptions.ios);
  } catch (_) {/* Authentication shows a recoverable connection message. */}
  runApp(const ProviderScope(child: HolyHerApp()));
}

class HolyHerApp extends ConsumerWidget {
  const HolyHerApp({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => MaterialApp(
      key: ValueKey(
          ref.watch(authProvider.select((state) => state.user?.uid)) ??
              'signed-out'),
      title: AppConstants.appName,
      theme: buildAppTheme(),
      debugShowCheckedModeBanner: false,
      builder: (context, child) => MediaQuery(
          data: MediaQuery.of(context).copyWith(
              textScaler: ref.watch(profileProvider.select((p) => p.largerText))
                  ? TextScaler.linear(
                      MediaQuery.textScalerOf(context).scale(16) / 16 * 1.15)
                  : MediaQuery.textScalerOf(context)),
          child: BlushBackdrop(child: child!)),
      home: const AppRoot());
}

class AppRoot extends ConsumerWidget {
  const AppRoot({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    if (auth.user == null) return const LandingScreen();
    return _SignedInRoot(key: ValueKey(auth.user!.uid));
  }
}

class _SignedInRoot extends ConsumerStatefulWidget {
  const _SignedInRoot({super.key});
  @override
  ConsumerState<_SignedInRoot> createState() => _SignedInRootState();
}

class _SignedInRootState extends ConsumerState<_SignedInRoot>
    with WidgetsBindingObserver {
  bool _booted = false;
  String? _error;
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
    _timer = Timer.periodic(const Duration(minutes: 1), (_) => _refresh());
  }

  Future<void> _bootstrap() async {
    if (mounted) {
      setState(() {
        _error = null;
        _booted = false;
      });
    }
    try {
      await ref.read(profileProvider.notifier).initialize();
      if (!mounted) return;
      await ref.read(progressProvider.notifier).initialize();
      if (!mounted) return;
      await ref.read(progressProvider.notifier).refresh();
      if (!mounted) return;
      unawaited(ref.read(attemptSyncProvider.notifier).sync());
      unawaited(ref.read(streakProvider.notifier).initialize());
      if (mounted) setState(() => _booted = true);
    } catch (_) {
      if (mounted) {
        setState(() => _error =
            'We could not load your saved journey. Check your connection, then try again.');
      }
    }
  }

  void _refresh() {
    if (!mounted || !_booted) return;
    unawaited(ref.read(savedProvider.notifier).sync());
    unawaited(ref
        .read(progressProvider.notifier)
        .refresh()
        .then((_) => ref.read(attemptSyncProvider.notifier).sync()));
    unawaited(ref
        .read(reminderServiceProvider)
        .reconcile(ref.read(profileProvider).reminderMinutes)
        .then((_) {
      if (mounted) ref.invalidate(reminderEnabledProvider);
    }).catchError((Object _) {}));
    unawaited(ref.read(streakProvider.notifier).checkAndUpdateStreak());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return HolyRecovery(
          message: _error!,
          onRetry: () {
            ref.invalidate(profileProvider);
            _bootstrap();
          },
          onSignOut: () => ref.read(authProvider.notifier).signOut());
    }
    if (!_booted) return const SplashScreen();
    final profile = ref.watch(profileProvider);
    if (!profile.onboardingComplete) return const OnboardingScreen();
    if (!ref.watch(progressProvider).journeyStarted) {
      return const BeginJourneyScreen();
    }
    return const HomeShell();
  }
}

class BeginJourneyScreen extends ConsumerStatefulWidget {
  const BeginJourneyScreen({super.key});
  @override
  ConsumerState<BeginJourneyScreen> createState() => _BeginJourneyState();
}

class _BeginJourneyState extends ConsumerState<BeginJourneyScreen> {
  bool _busy = false;
  String? _error;
  @override
  Widget build(BuildContext context) => HolyScaffold(
      body: Center(
          child: ReadingWidth(
              maxWidth: 560,
              child: SingleChildScrollView(
                  padding: const EdgeInsets.all(28),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const HolyMark(size: 80),
                    const SizedBox(height: 24),
                    Text('Your setup is ready.',
                        style: Theme.of(context).textTheme.headlineMedium),
                    const SizedBox(height: 16),
                    const Text(
                        'Begin your free 365-lesson journey. One more lesson opens each calendar day. Connect once to confirm your start date.'),
                    if (_error != null) InlineMessage(_error!, error: true),
                    const SizedBox(height: 24),
                    HolyButton(
                        label: 'Begin my journey',
                        busy: _busy,
                        onPressed: _busy
                            ? null
                            : () async {
                                setState(() {
                                  _busy = true;
                                  _error = null;
                                });
                                final navigator = Navigator.of(context);
                                try {
                                  await ref
                                      .read(progressProvider.notifier)
                                      .startJourney();
                                  if (navigator.mounted) {
                                    navigator.push(MaterialPageRoute(
                                        builder: (_) => LessonScreen(
                                            lesson: lessons.first)));
                                  }
                                } catch (_) {
                                  if (mounted) {
                                    setState(() => _error =
                                        'Your setup is saved. Reconnect and try again to begin.');
                                  }
                                } finally {
                                  if (mounted) setState(() => _busy = false);
                                }
                              })
                  ])))));
}
