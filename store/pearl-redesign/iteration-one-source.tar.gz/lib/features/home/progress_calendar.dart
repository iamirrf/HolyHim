import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/services/progress_service.dart';
import 'package:holyher/services/streak_service.dart';

class ProgressCalendar extends ConsumerStatefulWidget {
  const ProgressCalendar({super.key});
  @override
  ConsumerState<ProgressCalendar> createState() => _ProgressCalendarState();
}

class _ProgressCalendarState extends ConsumerState<ProgressCalendar> {
  DateTime? _month, _selected;
  static const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];
  @override
  Widget build(BuildContext context) {
    final progress = ref.watch(progressProvider),
        streak = ref.watch(streakProvider);
    final today =
        accountCalendarTime(ref.read(localClockProvider)(), progress.timeZone);
    final completedDates = progress.completionDates.values.toSet();
    _month ??= DateTime(today.year, today.month);
    final month = _month!,
        days = DateTime(month.year, month.month + 1, 0).day,
        offset = month.weekday % 7;
    String key(DateTime d) =>
        '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    bool same(DateTime? a, DateTime b) =>
        a != null && a.year == b.year && a.month == b.month && a.day == b.day;
    return HolyScaffold(
        title: 'Your journey',
        body: ReadingWidth(
            child: ListView(padding: const EdgeInsets.all(24), children: [
          const Text('Day by day.', style: HolyTypography.heading),
          const SizedBox(height: 24),
          Row(children: [
            Expanded(
                child: Text('${months[month.month - 1]} ${month.year}',
                    style: HolyTypography.section)),
            IconButton(
                tooltip: 'Previous month',
                onPressed: () => setState(
                    () => _month = DateTime(month.year, month.month - 1)),
                icon: const Icon(Icons.chevron_left)),
            IconButton(
                tooltip: 'Next month',
                onPressed: () => setState(
                    () => _month = DateTime(month.year, month.month + 1)),
                icon: const Icon(Icons.chevron_right))
          ]),
          const SizedBox(height: 16),
          Row(children: [
            for (final d in ['S', 'M', 'T', 'W', 'T', 'F', 'S'])
              Expanded(
                  child: Text(d,
                      textAlign: TextAlign.center, style: HolyTypography.label))
          ]),
          const SizedBox(height: 8),
          LayoutBuilder(
              builder: (context, box) => Column(children: [
                    for (var row = 0; row < ((offset + days) / 7).ceil(); row++)
                      Row(children: [
                        for (var col = 0; col < 7; col++)
                          Expanded(child: Builder(builder: (context) {
                            final n = row * 7 + col - offset + 1;
                            if (n < 1 || n > days) {
                              return const SizedBox(height: 48);
                            }
                            final date = DateTime(month.year, month.month, n),
                                complete = completedDates.contains(key(date)),
                                selected = same(_selected, date),
                                isToday = same(today, date);
                            return Semantics(
                                label:
                                    '${months[month.month - 1]} $n, ${complete ? 'lesson completed' : 'no recorded completion'}${isToday ? ', today' : ''}',
                                selected: selected,
                                child: HolyPressable(
                                    onPressed: () =>
                                        setState(() => _selected = date),
                                    child: Container(
                                        margin: const EdgeInsets.all(2),
                                        constraints:
                                            const BoxConstraints(minHeight: 44),
                                        decoration: BoxDecoration(
                                            color: selected
                                                ? AppColors.accent
                                                : complete
                                                    ? AppColors.surface
                                                    : Colors.transparent,
                                            borderRadius: BorderRadius.circular(
                                                selected ? 14 : 24),
                                            border: isToday
                                                ? Border.all(
                                                    color: AppColors.accent,
                                                    width: 1.5)
                                                : null),
                                        child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text('$n',
                                                  style: HolyTypography
                                                      .supporting
                                                      .copyWith(
                                                          color: selected
                                                              ? Colors.white
                                                              : AppColors
                                                                  .textPrimary,
                                                          fontFeatures: const [
                                                        FontFeature
                                                            .tabularFigures()
                                                      ])),
                                              if (complete)
                                                Icon(Icons.check_rounded,
                                                    size: 12,
                                                    color: selected
                                                        ? Colors.white
                                                        : AppColors.accent)
                                            ]))));
                          }))
                      ])
                  ])),
          const SizedBox(height: 20),
          if (_selected != null)
            InlineMessage(
                '${months[_selected!.month - 1]} ${_selected!.day} · ${completedDates.contains(key(_selected!)) ? 'A lesson completed.' : 'No recorded completion on this date.'}'),
          const SizedBox(height: 12),
          Text(
              '${streak.current} day current streak · ${streak.longest} day longest',
              style: HolyTypography.supporting),
          const SizedBox(height: 8),
          Text('Journey timezone · ${progress.timeZone ?? 'Not yet set'}',
              style: HolyTypography.supporting
                  .copyWith(color: AppColors.textSecondary)),
          if (progress.completedCount > progress.completionDates.length)
            const Padding(
                padding: EdgeInsets.only(top: 16),
                child: Text(
                    'Earlier lessons are counted in your total. Their completion dates are not available.',
                    style: HolyTypography.supporting)),
          const SectionLabel('Milestones'),
          for (final n in [7, 30, 90, 180, 365])
            MenuRow(
                title: '$n lessons',
                subtitle: progress.completedCount >= n
                    ? 'Reached · ${progress.completedCount} lessons completed'
                    : '${(n - progress.completedCount).clamp(0, n)} lessons to go',
                icon: progress.completedCount >= n
                    ? Icons.verified_outlined
                    : Icons.radio_button_unchecked,
                trailing: Icon(
                    progress.completedCount >= n
                        ? Icons.check_rounded
                        : Icons.lock_outline,
                    size: 20,
                    color: progress.completedCount >= n
                        ? AppColors.success
                        : AppColors.textSecondary)),
        ])));
  }
}
