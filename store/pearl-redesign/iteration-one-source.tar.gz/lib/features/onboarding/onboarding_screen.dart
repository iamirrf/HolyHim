import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/core/widgets/holy_ruler.dart';
import 'package:holyher/core/widgets/holy_material.dart';
import 'package:holyher/core/widgets/holy_loader.dart';
import 'package:holyher/data/lessons.dart';
import 'package:holyher/data/teaching.dart';
import 'package:holyher/features/onboarding/checkpoint.dart';
import 'package:holyher/features/onboarding/personalization.dart';
import 'package:holyher/features/support/support_screens.dart';
import 'package:holyher/services/auth_service.dart';
import 'package:holyher/services/profile_service.dart';
import 'package:holyher/services/progress_service.dart';
import 'package:holyher/features/lesson/lesson_screen.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  final bool editing;
  final String? initialStage;
  const OnboardingScreen({super.key, this.editing = false, this.initialStage});
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen>
    with WidgetsBindingObserver {
  late UserProfile _draft;
  late final TextEditingController _name;
  late int _step;
  final _pages = PageController();
  bool _busy = false, _summaryEdit = false, _saved = false, _navigating = false;
  String? _error;
  Future<void> _writes = Future.value();
  String get _id => OnboardingStages.ids[_step];
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _draft = ref.read(profileProvider);
    _step = widget.initialStage != null
        ? OnboardingStages.ids.indexOf(widget.initialStage!).clamp(0, 11)
        : widget.editing
            ? 8
            : _draft.onboardingStep.clamp(0, 11);
    _name = TextEditingController(
        text: _draft.name.isEmpty
            ? ref.read(authProvider).user?.displayName ?? ''
            : _draft.name);
    _name.addListener(() => _update(_draft.copyWith(name: _name.text.trim())));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _pages.jumpToPage(_step);
        if (_step == 9) _saveSetup();
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _name.dispose();
    _pages.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      unawaited(_writes
          .then((_) => ref.read(profileProvider.notifier).flushDraft())
          .catchError((Object _) {}));
    }
  }

  void _update(UserProfile value) {
    setState(() => _draft = value);
    final notifier = ref.read(profileProvider.notifier);
    _writes = _writes
        .catchError((Object _) {})
        .then((_) => notifier.saveDraft(value));
    unawaited(_writes.catchError((Object _) {
      if (mounted) {
        setState(() => _error = 'Your draft could not be saved. Please retry.');
      }
    }));
  }

  void _choose(String field, String value) {
    _update(_draft.copyWith(
        familiarity: field == 'starting-point' ? value : null,
        focus: field == 'focus' ? value : null,
        obstacle: field == 'barrier' ? value : null,
        onboardingAnswered: {..._draft.onboardingAnswered, field}));
  }

  bool get _valid => switch (_id) {
        'starting-point' ||
        'focus' ||
        'barrier' =>
          _draft.onboardingAnswered.contains(_id),
        'guided-example' =>
          _draft.guidedExampleAnswer != null && _draft.guidedExampleRevealed,
        'reminder' => _draft.reminderDecision != 'pending',
        'save' => _saved,
        _ => true
      };
  Future<void> _go(int index) async {
    if (_navigating) return;
    _navigating = true;
    try {
      FocusScope.of(context).unfocus();
      _draft = _draft.copyWith(onboardingStep: index);
      await _writes.catchError((Object _) {});
      await ref.read(profileProvider.notifier).saveDraft(_draft);
      if (!mounted) return;
      setState(() {
        _step = index;
        _error = null;
      });
      if (MediaQuery.disableAnimationsOf(context)) {
        _pages.jumpToPage(index);
      } else {
        await _pages.animateToPage(index,
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOutCubic);
      }
      if (index == 9) await _saveSetup();
    } finally {
      _navigating = false;
    }
  }

  Future<void> _next() async {
    if (_busy || !_valid) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      _draft = _draft.copyWith(
          name: _name.text.trim(),
          onboardingAnswered: {..._draft.onboardingAnswered, _id});
      if (_summaryEdit) {
        _summaryEdit = false;
        await _go(8);
      } else if (_step == 11) {
        final navigator = Navigator.of(context);
        await _writes.catchError((Object _) {});
        await ref.read(progressProvider.notifier).startJourney();
        await ref
            .read(profileProvider.notifier)
            .save(_draft.copyWith(onboardingComplete: true));
        if (navigator.mounted) {
          navigator.push(MaterialPageRoute(
              builder: (_) => LessonScreen(lesson: lessons.first)));
        }
      } else if (widget.editing && _step == 8) {
        await _writes.catchError((Object _) {});
        await ref.read(profileProvider.notifier).save(_draft);
        if (mounted) Navigator.pop(context);
      } else {
        await _go(_step + 1);
      }
    } catch (_) {
      if (mounted) {
        setState(() => _error =
            'Your setup stays on this device. Reconnect and retry to finish saving.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveSetup() async {
    setState(() {
      _busy = true;
      _saved = false;
      _error = null;
    });
    try {
      await _writes.catchError((Object _) {});
      await ref.read(profileProvider.notifier).save(_draft);
      if (mounted) setState(() => _saved = true);
    } catch (_) {
      if (mounted) {
        setState(() => _error =
            'Your setup could not finish saving. Reconnect and retry.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _back() {
    if (_busy) return;
    if (_summaryEdit) {
      _summaryEdit = false;
      unawaited(_go(8));
    } else if (widget.editing && _step == 8) {
      Navigator.pop(context);
    } else if (_step > 0) {
      unawaited(_go(_step - 1));
    } else {
      ref.read(authProvider.notifier).signOut();
    }
  }

  Future<void> _remind() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _writes.catchError((Object _) {});
      await ref
          .read(profileProvider.notifier)
          .setReminder(_draft.suggestedReminderMinutes ?? 480);
      _update(_draft.copyWith(
          reminderMinutes: _draft.suggestedReminderMinutes ?? 480,
          reminderDecision: 'enabled',
          onboardingAnswered: {..._draft.onboardingAnswered, 'reminder'}));
    } on StateError catch (e) {
      if (e.message.toString().contains('Allow notifications')) {
        _update(_draft.copyWith(reminderDecision: 'denied'));
      } else {
        if (mounted) {
          setState(() =>
              _error = 'Your reminder could not finish saving. Please retry.');
        }
      }
    } catch (_) {
      if (mounted) {
        setState(() =>
            _error = 'Your reminder could not finish saving. Please retry.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _time() async {
    final m = _draft.suggestedReminderMinutes ?? 480;
    final t = await showTimePicker(
        context: context,
        initialTime: TimeOfDay(hour: m ~/ 60, minute: m % 60));
    if (t != null) {
      _update(
          _draft.copyWith(suggestedReminderMinutes: t.hour * 60 + t.minute));
    }
  }

  static const _titles = [
    'What should we call you?',
    'When could this moment be yours?',
    'Where are you starting?',
    'What tends to get in the way?',
    'Let’s try one together.',
    'One small step, each day.',
    'What would you like more room for?',
    'A gentle reminder?',
    'Your rhythm, at a glance.',
    'Making room for your day.',
    'Here’s where you begin.',
    'Your first day is ready.'
  ];
  @override
  Widget build(BuildContext context) {
    return PopScope(
        canPop: widget.editing && !_busy,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) _back();
        },
        child: HolyScaffold(
            body: ReadingWidth(
                maxWidth: 720,
                child: Column(children: [
                  SizedBox(
                      height: 56,
                      child: Row(children: [
                        IconButton(
                            tooltip: 'Previous step',
                            onPressed: _busy ? null : _back,
                            icon: const Icon(Icons.arrow_back_rounded)),
                        Expanded(
                            child: Semantics(
                                label: 'Setup progress',
                                value: '${_step + 1} of 12',
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      for (var i = 0; i < 12; i++)
                                        AnimatedContainer(
                                            duration:
                                                MediaQuery.disableAnimationsOf(
                                                        context)
                                                    ? Duration.zero
                                                    : const Duration(
                                                        milliseconds: 400),
                                            margin: const EdgeInsets.symmetric(
                                                horizontal: 2.5),
                                            height: 8,
                                            width: i == _step ? 32 : 8,
                                            decoration: BoxDecoration(
                                                color: i <= _step
                                                    ? AppColors.accent
                                                    : AppColors.divider,
                                                borderRadius:
                                                    BorderRadius.circular(4)))
                                    ]))),
                        const SizedBox(width: 44)
                      ])),
                  Expanded(
                      child: PageView(
                          controller: _pages,
                          physics: const NeverScrollableScrollPhysics(),
                          children: [
                        for (var i = 0; i < 12; i++)
                          TickerMode(
                              enabled: i == _step,
                              child: SingleChildScrollView(
                                  key: PageStorageKey(
                                      'onboarding-${OnboardingStages.ids[i]}'),
                                  padding:
                                      const EdgeInsets.fromLTRB(24, 20, 24, 24),
                                  child: ReadingWidth(
                                      maxWidth: 488,
                                      child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            ConstrainedBox(
                                                constraints:
                                                    const BoxConstraints(
                                                        minHeight: 76),
                                                child: Text(
                                                    i == 9 && _saved
                                                        ? 'Your setup is ready.'
                                                        : _titles[i],
                                                    style:
                                                        HolyTypography.heading,
                                                    textAlign: i == 0 || i == 11
                                                        ? TextAlign.center
                                                        : TextAlign.start)),
                                            const SizedBox(height: 20),
                                            ..._content(i),
                                          ]))))
                      ])),
                  HolyFadingMaterial(
                      bottom: true,
                      child: ReadingWidth(
                          maxWidth: 536,
                          child: Padding(
                              padding: EdgeInsets.fromLTRB(
                                  24,
                                  MediaQuery.viewInsetsOf(context).bottom > 0
                                      ? 8
                                      : 24,
                                  24,
                                  12),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    if (_error != null) ...[
                                      InlineMessage(_error!, error: true),
                                      if (_step == 9)
                                        TextButton(
                                            onPressed:
                                                _busy ? null : _saveSetup,
                                            child: const Text('Retry saving'))
                                    ],
                                    HolyButton(
                                        label: _summaryEdit
                                            ? 'Return to summary'
                                            : _step == 8
                                                ? 'Save my setup'
                                                : _step == 9
                                                    ? 'See Day 1'
                                                    : _step == 11
                                                        ? 'Begin my journey'
                                                        : 'Continue',
                                        busy: _busy,
                                        onPressed:
                                            _valid && !_busy ? _next : null),
                                    if (_step == 0 || _step == 1)
                                      TextButton(
                                          onPressed: _busy
                                              ? null
                                              : () {
                                                  if (_step == 1) {
                                                    _draft = _draft.copyWith(
                                                        clearSuggestedReminder:
                                                            true);
                                                  }
                                                  _next();
                                                },
                                          child: Text(_step == 0
                                              ? 'Skip'
                                              : 'Choose later')),
                                  ])))),
                ]))));
  }

  List<Widget> _content(int step) {
    switch (step) {
      case 0:
        return [
          const SizedBox(height: 20),
          const Center(child: HolyMark(size: 72)),
          const SizedBox(height: 36),
          TextField(
              controller: _name,
              maxLength: 40,
              textCapitalization: TextCapitalization.words,
              autofillHints: const [AutofillHints.givenName],
              style: HolyTypography.reading,
              textInputAction: TextInputAction.done,
              decoration: const InputDecoration(
                  labelText: 'Preferred name', counterText: ''),
              onSubmitted: (_) => _next())
        ];
      case 1:
        return [
          HolyTimeRuler(
              minutes: _draft.suggestedReminderMinutes ?? 480,
              onChanged: (m) => _update(_draft.copyWith(
                      suggestedReminderMinutes: m,
                      onboardingAnswered: {
                        ..._draft.onboardingAnswered,
                        'moment'
                      })))
        ];
      case 2:
        return _options('starting-point', [
          (
            id: 'new',
            label: 'New to the Bible',
            icon: Icons.menu_book_outlined
          ),
          (
            id: 'returning',
            label: 'Returning to the Bible',
            icon: Icons.history_rounded
          ),
          (
            id: 'regular',
            label: 'Reading regularly',
            icon: Icons.auto_stories_outlined
          )
        ]);
      case 3:
        return _options('barrier', [
          (id: 'busy', label: 'Busy days', icon: Icons.schedule_rounded),
          (
            id: 'forget',
            label: 'I forget',
            icon: Icons.notifications_none_rounded
          ),
          (
            id: 'language',
            label: 'Unfamiliar wording',
            icon: Icons.text_fields_rounded
          ),
          (
            id: 'apply',
            label: 'Putting it into practice',
            icon: Icons.route_outlined
          )
        ]);
      case 4:
        return [
          GuidedExampleConversation(
              selected: _draft.guidedExampleAnswer,
              revealed: _draft.guidedExampleRevealed,
              onReveal: () =>
                  _update(_draft.copyWith(guidedExampleRevealed: true)),
              onAnswer: (id) => _update(_draft.copyWith(
                      guidedExampleAnswer: id,
                      guidedExampleRevealed:
                          MediaQuery.disableAnimationsOf(context),
                      onboardingAnswered: {
                        ..._draft.onboardingAnswered,
                        'guided-example'
                      })))
        ];
      case 5:
        return [
          const DailyRhythmDiagram(),
          const SizedBox(height: 32),
          const Text('A new lesson opens each day.',
              textAlign: TextAlign.center, style: HolyTypography.supporting)
        ];
      case 6:
        return _options('focus', [
          (id: 'peace', label: 'Peace', icon: Icons.water_outlined),
          (
            id: 'confidence',
            label: 'Confidence',
            icon: Icons.wb_sunny_outlined
          ),
          (id: 'hope', label: 'Hope', icon: Icons.wb_twilight_rounded),
          (id: 'guidance', label: 'Guidance', icon: Icons.explore_outlined),
          (id: 'rest', label: 'Rest', icon: Icons.bedtime_outlined)
        ]);
      case 7:
        return [
          const Row(children: [
            HolyMark(size: 32),
            SizedBox(width: 10),
            Expanded(
                child:
                    Text('Your daily moment', style: HolyTypography.supporting))
          ]),
          const SizedBox(height: 24),
          const QuietInset(
              child: Text('Would a little nudge help you make room?')),
          const SizedBox(height: 20),
          Align(
              alignment: Alignment.centerRight,
              child: ActionChip(
                  avatar: const Icon(Icons.schedule, size: 18),
                  label: Text(_draft.suggestedReminderMinutes == null
                      ? 'Choose a time'
                      : TimeOfDay(
                              hour: _draft.suggestedReminderMinutes! ~/ 60,
                              minute: _draft.suggestedReminderMinutes! % 60)
                          .format(context)),
                  onPressed: _busy ? null : _time)),
          const SizedBox(height: 20),
          if (_draft.reminderDecision == 'pending') ...[
            HolyButton(
                label: 'Remind me',
                secondary: true,
                onPressed: _busy ? null : _remind),
            TextButton(
                onPressed: _busy
                    ? null
                    : () =>
                        _update(_draft.copyWith(reminderDecision: 'declined')),
                child: const Text('Not now')),
          ] else ...[
            InlineMessage(_draft.reminderDecision == 'enabled'
                ? 'Your reminder is on.'
                : _draft.reminderDecision == 'denied'
                    ? 'Reminders are off.'
                    : 'No reminder. Your moment is here whenever you are.'),
            if (_draft.reminderDecision == 'denied')
              TextButton(
                  onPressed: () => openExternal(context, 'app-settings:'),
                  child: const Text('Open Settings')),
            if (_draft.reminderDecision != 'enabled')
              TextButton(
                  onPressed: _busy ? null : _remind,
                  child: const Text('Try enabling reminder')),
          ]
        ];
      case 8:
        return [
          Center(
              child: Container(
                  width: 96,
                  height: 96,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                          colors: [Colors.white, AppColors.surface]),
                      border: Border.all(
                          color: AppColors.accent.withValues(alpha: .35))),
                  child: Text(
                      _name.text.trim().isEmpty
                          ? 'H'
                          : String.fromCharCode(_name.text.trim().runes.first)
                              .toUpperCase(),
                      style: HolyTypography.display
                          .copyWith(color: AppColors.accent)))),
          const SizedBox(height: 20),
          Text(
              _name.text.trim().isEmpty
                  ? 'Your daily moment'
                  : _name.text.trim(),
              textAlign: TextAlign.center,
              style: HolyTypography.section),
          const SizedBox(height: 24),
          _editRow('Name',
              _name.text.trim().isEmpty ? 'Not added' : _name.text.trim(), 0),
          _editRow('Starting point', familiarityLabel(_draft.familiarity), 2),
          _editRow('Focus', focusLabel(_draft.focus), 6),
          _editRow(
              'Obstacle',
              const {
                    'busy': 'Busy days',
                    'forget': 'I forget',
                    'language': 'Unfamiliar wording',
                    'apply': 'Putting it into practice'
                  }[_draft.obstacle] ??
                  'Busy days',
              3),
          _editRow(
              'Reminder',
              _draft.reminderDecision == 'enabled'
                  ? reminderLabel(_draft.reminderMinutes, context: context)
                  : 'Off',
              7),
        ];
      case 9:
        return [
          if (_busy)
            const PulsingDotsLoader(semanticsLabel: 'Saving setup')
          else if (_saved)
            const Center(
                child: Icon(Icons.check_circle_outline_rounded,
                    size: 36, color: AppColors.success)),
          const SizedBox(height: 24),
          LayoutBuilder(builder: (context, box) {
            double measure(String text, TextStyle style) {
              final painter = TextPainter(
                  text: TextSpan(text: text, style: style),
                  textDirection: Directionality.of(context),
                  textScaler: MediaQuery.textScalerOf(context))
                ..layout(maxWidth: 170);
              return painter.height;
            }

            final height = lessons
                .take(3)
                .map((l) =>
                    40 +
                    measure('DAY 01', HolyTypography.label) +
                    16 +
                    28 +
                    16 +
                    measure(l.title, HolyTypography.section) +
                    12 +
                    measure(l.verseReference, HolyTypography.supporting) +
                    64)
                .reduce((a, b) => a > b ? a : b);
            return SizedBox(height: height, child: _PlanFan(ready: _saved));
          }),
          Text(
              _saved
                  ? 'Your first lessons, ready to explore.'
                  : _error != null
                      ? 'Your choices are kept for retry.'
                      : 'Saving your choices to your account.',
              textAlign: TextAlign.center,
              style: HolyTypography.supporting),
        ];
      case 10:
        return [
          Text(lessons.first.title, style: HolyTypography.section),
          const SizedBox(height: 24),
          _DayOnePreview(active: _step == 10)
        ];
      default:
        return [
          const SizedBox(height: 12),
          const Center(child: HolyMark(size: 112)),
          const SizedBox(height: 32),
          Center(
              child: SizedBox(
                  width: 230, child: LessonMiniature(lesson: lessons.first))),
          const SizedBox(height: 32),
          for (final text in [
            'Begin with Day 1.',
            'One new message each day.',
            'Keep every unlocked lesson.'
          ])
            Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(children: [
                  const Icon(Icons.check_circle_outline_rounded,
                      size: 22, color: AppColors.accent),
                  const SizedBox(width: 16),
                  Expanded(child: Text(text))
                ])),
        ];
    }
  }

  Widget _editRow(String title, String value, int index) => MenuRow(
      title: title,
      subtitle: value,
      icon: Icons.edit_outlined,
      onTap: () {
        _summaryEdit = true;
        unawaited(_go(index));
      });
  List<Widget> _options(
      String field, List<({String id, String label, IconData icon})> options) {
    final value = field == 'focus'
        ? _draft.focus
        : field == 'barrier'
            ? _draft.obstacle
            : _draft.familiarity;
    return [
      for (final option in options)
        Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: HolyPressable(
                selected: _draft.onboardingAnswered.contains(field) &&
                    value == option.id,
                onPressed: () => _choose(field, option.id),
                child: QuietInset(
                    selected: _draft.onboardingAnswered.contains(field) &&
                        value == option.id,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 18),
                    child: Row(children: [
                      Icon(option.icon, color: AppColors.accent, size: 26),
                      const SizedBox(width: 16),
                      Expanded(
                          child:
                              Text(option.label, style: HolyTypography.body)),
                      const SizedBox(width: 12),
                      Icon(
                          _draft.onboardingAnswered.contains(field) &&
                                  value == option.id
                              ? Icons.check_circle_rounded
                              : Icons.circle_outlined,
                          color: _draft.onboardingAnswered.contains(field) &&
                                  value == option.id
                              ? AppColors.accent
                              : AppColors.textSecondary,
                          size: 22)
                    ]))))
    ];
  }
}

class GuidedExampleConversation extends StatefulWidget {
  final String? selected;
  final bool revealed;
  final ValueChanged<String> onAnswer;
  final VoidCallback onReveal;
  const GuidedExampleConversation(
      {super.key,
      required this.selected,
      required this.revealed,
      required this.onAnswer,
      required this.onReveal});
  @override
  State<GuidedExampleConversation> createState() => _GuidedExampleState();
}

class _GuidedExampleState extends State<GuidedExampleConversation>
    with WidgetsBindingObserver {
  Timer? _timer;
  bool _questionVisible = false, _foreground = true;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.disableAnimationsOf(context)) _questionVisible = true;
    _schedule();
  }

  @override
  void didUpdateWidget(GuidedExampleConversation old) {
    super.didUpdateWidget(old);
    if (widget.selected != old.selected || widget.revealed != old.revealed) {
      _timer?.cancel();
      _timer = null;
      _schedule();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    _schedule();
  }

  void _schedule() {
    if (!_foreground || !TickerMode.valuesOf(context).enabled) {
      _timer?.cancel();
      _timer = null;
      return;
    }
    if (_timer?.isActive == true) return;
    if (!_questionVisible) {
      _timer = Timer(const Duration(milliseconds: 550), () {
        _timer = null;
        if (mounted) {
          setState(() => _questionVisible = true);
          _schedule();
        }
      });
    } else if (widget.selected != null && !widget.revealed) {
      _timer = Timer(
          MediaQuery.disableAnimationsOf(context)
              ? Duration.zero
              : const Duration(milliseconds: 600), () {
        _timer = null;
        if (mounted) widget.onReveal();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final teaching = teachingCatalog[1]!, q = teaching.questions.first;
    final selected = widget.selected;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Row(children: [
        HolyMark(size: 32),
        SizedBox(width: 10),
        Expanded(
            child: Text('A guided example', style: HolyTypography.supporting))
      ]),
      const SizedBox(height: 20),
      QuietInset(
          child: Text(teaching.context.split('. ').last,
              style: HolyTypography.body)),
      const SizedBox(height: 16),
      AnimatedSwitcher(
          duration: MediaQuery.disableAnimationsOf(context)
              ? Duration.zero
              : const Duration(milliseconds: 300),
          child: !_questionVisible
              ? const PulsingDotsLoader(
                  key: ValueKey('scripted-question-reveal'),
                  semanticsLabel: 'Revealing the practice question')
              : Column(
                  key: const ValueKey('practice-question'),
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                      Text(q.prompt, style: HolyTypography.action),
                      const SizedBox(height: 16),
                      if (selected == null)
                        for (final option in q.options)
                          Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: HolyPressable(
                                  onPressed: () => widget.onAnswer(option.id),
                                  child: QuietInset(child: Text(option.text)))),
                      if (selected != null) ...[
                        Align(
                            alignment: Alignment.centerRight,
                            child: QuietInset(
                                selected: true,
                                child: Text(q.options
                                    .firstWhere((o) => o.id == selected,
                                        orElse: () => q.options.first)
                                    .text))),
                        const SizedBox(height: 16),
                        if (!widget.revealed)
                          const PulsingDotsLoader(
                              semanticsLabel:
                                  'Revealing the authored explanation')
                        else
                          Semantics(
                              liveRegion: true,
                              child: QuietInset(
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                    Row(children: [
                                      Icon(
                                          selected == q.correctOptionId
                                              ? Icons.check_circle_outline
                                              : Icons.info_outline,
                                          color: selected == q.correctOptionId
                                              ? AppColors.success
                                              : AppColors.accent),
                                      const SizedBox(width: 10),
                                      Expanded(
                                          child: Text(
                                              selected == q.correctOptionId
                                                  ? 'That’s right.'
                                                  : 'Let’s look together.',
                                              style: HolyTypography.action))
                                    ]),
                                    const SizedBox(height: 12),
                                    Text(q.explanation)
                                  ]))),
                      ],
                    ])),
      const SizedBox(height: 16),
      const Text('Practice only · your Day 1 progress stays separate.',
          style: HolyTypography.supporting),
    ]);
  }
}

class DailyRhythmDiagram extends StatelessWidget {
  const DailyRhythmDiagram({super.key});
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
      tween:
          Tween(begin: MediaQuery.disableAnimationsOf(context) ? 1 : 0, end: 1),
      duration: const Duration(milliseconds: 1600),
      curve: Curves.easeOutCubic,
      builder: (context, value, _) => Column(children: [
            for (var i = 0; i < 3; i++) ...[
              if (i > 0)
                Align(
                    alignment: Alignment.center,
                    child: Container(
                        width: 2,
                        height: 32 * value,
                        color: AppColors.accent.withValues(alpha: .4))),
              SizedBox(
                  width: 260,
                  child: PearlSurface(
                      padding: const EdgeInsets.all(20),
                      ribbon: i == 2,
                      child: Row(children: [
                        Icon(
                            [
                              Icons.menu_book_outlined,
                              Icons.lightbulb_outline,
                              Icons.bookmark_outline
                            ][i],
                            color: AppColors.accent,
                            size: 28),
                        const SizedBox(width: 20),
                        Expanded(
                            child: Text(['Read', 'Understand', 'Carry'][i],
                                style: HolyTypography.section))
                      ]))),
            ]
          ]));
}

class _PlanFan extends StatelessWidget {
  final bool ready;
  const _PlanFan({required this.ready});
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: ready ? 1 : 0),
      duration: Duration(
          milliseconds: MediaQuery.disableAnimationsOf(context) ? 0 : 620),
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => Stack(
              alignment: Alignment.center,
              clipBehavior: Clip.none,
              children: [
                for (var i = 0; i < 3; i++)
                  Transform.translate(
                      offset: Offset((i - 1) * 48.0 * t, i == 1 ? 0 : 24 * t),
                      child: Transform.rotate(
                          angle: [-.09, .025, .09][i] * t,
                          child: SizedBox(
                              width: 210,
                              child: LessonMiniature(lesson: lessons[i]))))
              ]));
}

class _DayOnePreview extends StatefulWidget {
  final bool active;
  const _DayOnePreview({required this.active});
  @override
  State<_DayOnePreview> createState() => _DayOnePreviewState();
}

class _DayOnePreviewState extends State<_DayOnePreview>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 620));
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _start();
  }

  @override
  void didUpdateWidget(_DayOnePreview old) {
    super.didUpdateWidget(old);
    if (widget.active && !old.active) _start();
  }

  void _start() {
    if (!widget.active) return;
    if (MediaQuery.disableAnimationsOf(context)) {
      _controller.value = 1;
    } else if (_controller.isDismissed) {
      _controller.forward();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
      animation: _controller,
      child: ScripturePage(lesson: lessons.first),
      builder: (context, child) {
        final t = Curves.easeOutCubic.transform(_controller.value);
        return Transform.translate(
            offset: Offset(0, 22 * (1 - t)),
            child: Transform.scale(
                scale: .96 + .04 * t,
                child: Opacity(opacity: .7 + .3 * t, child: child)));
      });
}
