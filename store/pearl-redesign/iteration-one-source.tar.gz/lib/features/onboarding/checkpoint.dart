/// Semantic positions survive presentation changes and avoid replaying newly
/// inserted interludes when an older checkpoint resumes.
abstract final class OnboardingStages {
  static const ids = [
    'name',
    'moment',
    'starting-point',
    'barrier',
    'guided-example',
    'daily-rhythm',
    'focus',
    'reminder',
    'summary',
    'save',
    'day-one',
    'arrival'
  ];
  static const v2 = [
    'name',
    'starting-point',
    'focus',
    'barrier',
    'suggested-rhythm',
    'reminder',
    'learning-preview',
    'summary',
    'save',
    'day-one'
  ];
  static const v1ToV2 = [0, 1, 2, 3, 5, 7, 9];
  static const renamed = {
    'suggested-rhythm': 'daily-rhythm',
    'learning-preview': 'guided-example'
  };
  static int migrate(Map<String, dynamic> data) {
    final version = data['onboardingVersion'];
    final id = data['onboardingStepId'];
    if (version == 3 && id is String && ids.contains(id)) {
      return ids.indexOf(id);
    }
    final numeric =
        data['onboardingStep'] is int ? data['onboardingStep'] as int : 0;
    if (version == 3) return numeric.clamp(0, 11);
    final oldIndex =
        version == 2 ? numeric.clamp(0, 9) : v1ToV2[numeric.clamp(0, 6)];
    final oldId =
        version == 2 && id is String && v2.contains(id) ? id : v2[oldIndex];
    return ids.indexOf(renamed[oldId] ?? oldId);
  }

  static Set<String> answered(Map<String, dynamic> data) {
    final list = data['onboardingAnswered'];
    if (data['onboardingVersion'] == 3 && list is List) {
      return list.whereType<String>().where(ids.contains).toSet();
    }
    return {
      if (data['name'] is String && (data['name'] as String).isNotEmpty) 'name',
      if (data['familiarity'] is String) 'starting-point',
      if (data['focus'] is String) 'focus',
      if (data['obstacle'] is String) 'barrier',
      if (data['reminderMinutes'] is int) 'reminder'
    };
  }
}
