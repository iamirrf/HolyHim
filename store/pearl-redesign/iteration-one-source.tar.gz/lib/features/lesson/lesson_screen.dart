import 'package:flutter/material.dart';
import 'package:holyher/features/lesson/lesson_pause.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/features/home/saved_tab.dart';
import 'package:holyher/data/lessons.dart';
import 'package:holyher/features/lesson/lesson_cards.dart';
import 'package:holyher/services/progress_service.dart';
import 'package:holyher/data/teaching.dart';
import 'package:holyher/features/lesson/guided_lesson.dart';

class LessonScreen extends ConsumerStatefulWidget {
  final DailyLesson lesson;
  const LessonScreen({super.key, required this.lesson});
  @override
  ConsumerState<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends ConsumerState<LessonScreen> {
  final _cards = LessonCardsController();
  bool _saving = false;
  bool _celebrating = false;
  String? _error;
  Future<bool> _complete() async {
    if (_saving) return false;
    if (ref.read(progressProvider).completedDays.contains(widget.lesson.day)) {
      Navigator.of(context).pop();
      return true;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await ref.read(progressProvider.notifier).completeDay(widget.lesson.day);
      if (!mounted) return true;
      setState(() {
        _celebrating = true;
        _saving = false;
      });
      return true;
    } catch (_) {
      if (mounted) {
        setState(() {
          _saving = false;
          _error = 'Your completion could not be saved. Please try again.';
        });
      }
      return false;
    }
  }

  Future<void> _pause() async {
    if (_saving) return;
    final leave = await showLessonPause(context);
    if (leave != true || !mounted) return;
    try {
      await _cards.save();
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) {
        setState(() => _error =
            'Your place could not be saved. Please retry before leaving.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = ref.watch(progressProvider);
    final allowed = progress.isUnlocked(widget.lesson.day);
    if (allowed && teachingCatalog.containsKey(widget.lesson.day)) {
      return GuidedLesson(lesson: widget.lesson);
    }
    return PopScope(
        canPop: _celebrating || !allowed,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) _pause();
        },
        child: HolyScaffold(
            body: !allowed
                ? Center(
                    child: Padding(
                        padding: const EdgeInsets.all(30),
                        child: GlassSurface(
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                              const Icon(Icons.lock_outline_rounded,
                                  color: AppColors.accent, size: 36),
                              const SizedBox(height: 18),
                              Text('Day ${widget.lesson.day} is still ahead.',
                                  style:
                                      Theme.of(context).textTheme.titleLarge),
                              const SizedBox(height: 12),
                              const Text(
                                  'One new lesson opens each calendar day. Enjoy the message waiting for you today.',
                                  textAlign: TextAlign.center)
                            ]))))
                : _celebrating
                    ? _CompletedLesson(
                        day: widget.lesson.day,
                        pending:
                            progress.pendingDays.contains(widget.lesson.day))
                    : Column(children: [
                        Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Row(children: [
                              IconButton(
                                  tooltip: 'Close lesson',
                                  onPressed: _pause,
                                  icon: const Icon(Icons.close)),
                              Expanded(
                                  child: Text('Day ${widget.lesson.day}',
                                      textAlign: TextAlign.center,
                                      style: HolyTypography.supporting)),
                              SaveLessonButton(day: widget.lesson.day)
                            ])),
                        if (_error != null)
                          Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 24),
                              child: InlineMessage(_error!, error: true)),
                        Expanded(
                            child: LessonCards(
                                lesson: widget.lesson,
                                controller: _cards,
                                done: progress.completedDays
                                    .contains(widget.lesson.day),
                                saving: _saving,
                                onComplete: _complete))
                      ])));
  }
}

class _CompletedLesson extends StatefulWidget {
  final int day;
  final bool pending;
  const _CompletedLesson({required this.day, required this.pending});
  @override
  State<_CompletedLesson> createState() => _CompletedLessonState();
}

class _CompletedLessonState extends State<_CompletedLesson>
    with SingleTickerProviderStateMixin {
  late final _animation = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2800));
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.disableAnimationsOf(context)) {
      _animation.value = 1;
    } else if (!_animation.isAnimating && _animation.value == 0) {
      _animation.forward();
    }
  }

  @override
  void dispose() {
    _animation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ReadingWidth(
      maxWidth: 550,
      child: LayoutBuilder(
          builder: (context, box) => SingleChildScrollView(
              padding: const EdgeInsets.all(28),
              child: ConstrainedBox(
                  constraints: BoxConstraints(
                      minHeight:
                          (box.maxHeight - 56).clamp(0, double.infinity)),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CompletionOrbit(animation: _animation, accepted: true),
                        const SizedBox(height: 35),
                        Eyebrow('Day ${widget.day} · Complete'),
                        const SizedBox(height: 14),
                        Text('Let it stay\nwith you.',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.headlineLarge),
                        const SizedBox(height: 18),
                        const Text(
                            'You made a little room for faith today.\nCarry one thought into what comes next.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 15,
                                height: 1.8,
                                color: AppColors.textSecondary)),
                        if (widget.pending) ...[
                          const SizedBox(height: 18),
                          const Text(
                              'Saved on this device. Your progress will sync when you’re online.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 12,
                                  height: 1.6,
                                  color: AppColors.textSecondary))
                        ],
                        const SizedBox(height: 35),
                        HolyButton(
                            label: 'Return to my day',
                            onPressed: () => Navigator.of(context).pop(),
                            icon: Icons.arrow_forward_rounded),
                      ])))));
}
