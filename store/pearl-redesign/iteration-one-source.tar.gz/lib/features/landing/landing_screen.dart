import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/core/widgets/google_mark.dart';
import 'package:holyher/features/landing/welcome_scenes.dart';
import 'package:holyher/features/auth/auth_screen.dart';
import 'package:holyher/features/support/support_screens.dart';
import 'package:holyher/services/auth_service.dart';

class LandingScreen extends ConsumerStatefulWidget {
  const LandingScreen({super.key});
  @override
  ConsumerState<LandingScreen> createState() => _LandingScreenState();
}

class _LandingScreenState extends ConsumerState<LandingScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  final _pages = PageController();
  late final _loop = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 4200), value: .25);
  Timer? _timer;
  int _page = 0;
  bool _foreground = true;
  static const titles = [
    'A moment with God.',
    'One day at a time.',
    'Words to carry with you.'
  ];
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _schedule();
  }

  void _schedule() {
    _timer?.cancel();
    if (!_foreground ||
        MediaQuery.disableAnimationsOf(context) ||
        !TickerMode.valuesOf(context).enabled) {
      _loop.stop();
      return;
    }
    if (!_loop.isAnimating) _loop.repeat();
    _timer = Timer(const Duration(seconds: 5), () {
      if (mounted && _pages.hasClients) _select((_page + 1) % 3);
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    _schedule();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _loop.dispose();
    _pages.dispose();
    super.dispose();
  }

  void _select(int index) {
    _timer?.cancel();
    if (MediaQuery.disableAnimationsOf(context)) {
      _pages.jumpToPage(index);
    } else {
      _pages.animateToPage(index,
          duration: const Duration(milliseconds: 680),
          curve: Curves.easeOutCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authProvider);
    return HolyScaffold(
        body: ReadingWidth(
            maxWidth: 488,
            child: LayoutBuilder(builder: (context, box) {
              final large = MediaQuery.textScalerOf(context).scale(17) > 20 ||
                  box.maxHeight < 540;
              double captionHeight(String title) {
                final painter = TextPainter(
                    text: TextSpan(text: title, style: HolyTypography.heading),
                    textDirection: Directionality.of(context),
                    textScaler: MediaQuery.textScalerOf(context))
                  ..layout(maxWidth: box.maxWidth - 48);
                return painter.height;
              }

              final captionSpace =
                  titles.map(captionHeight).reduce((a, b) => a > b ? a : b);
              final stageLimit = MediaQuery.sizeOf(context).width >= 700
                  ? box.maxHeight
                  : 350.0;
              final stageHeight = large
                  ? 130.0
                  : (box.maxHeight - 400 - captionSpace)
                      .clamp(100.0, stageLimit);
              final content = Column(mainAxisSize: MainAxisSize.min, children: [
                const SizedBox(height: 12),
                const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      HolyMark(size: 36),
                      SizedBox(width: 8),
                      Text('HolyHer',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w600))
                    ]),
                const SizedBox(height: 12),
                SizedBox(
                    height: stageHeight,
                    child: NotificationListener<ScrollNotification>(
                        onNotification: (n) {
                          if (n is ScrollStartNotification) _timer?.cancel();
                          if (n is ScrollEndNotification) _schedule();
                          return false;
                        },
                        child: PageView(
                            controller: _pages,
                            onPageChanged: (i) {
                              setState(() => _page = i);
                              _schedule();
                            },
                            children: [
                              for (var i = 0; i < 3; i++)
                                AnimatedBuilder(
                                    animation: _loop,
                                    builder: (context, _) =>
                                        WelcomeProductScene(
                                            index: i, phase: _loop.value))
                            ]))),
                const SizedBox(height: 12),
                Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: AnimatedSwitcher(
                        duration: MediaQuery.disableAnimationsOf(context)
                            ? Duration.zero
                            : const Duration(milliseconds: 420),
                        child: Text(titles[_page],
                            key: ValueKey(_page),
                            textAlign: TextAlign.center,
                            style: HolyTypography.heading))),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  for (var i = 0; i < 3; i++)
                    Semantics(
                        selected: i == _page,
                        child: HolyPressable(
                            label: 'Show ${[
                              'learning',
                              'continuity',
                              'saved Scripture'
                            ][i]} preview',
                            onPressed: () => _select(i),
                            child: SizedBox(
                                width: 44,
                                height: 44,
                                child: Center(
                                    child: AnimatedContainer(
                                        duration:
                                            const Duration(milliseconds: 320),
                                        height: 6,
                                        width: i == _page ? 22 : 6,
                                        decoration: BoxDecoration(
                                            color: i == _page
                                                ? AppColors.accent
                                                : AppColors.divider,
                                            borderRadius:
                                                BorderRadius.circular(6)))))))
                ]),
                Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(children: [
                      HolyButton(
                          label: 'Continue with Apple',
                          leading: const Icon(Icons.apple,
                              color: Colors.black, size: 23),
                          secondary: true,
                          foregroundColor: Colors.black,
                          busy: auth.loading && auth.action == AuthAction.apple,
                          onPressed: auth.loading
                              ? null
                              : () => ref
                                  .read(authProvider.notifier)
                                  .signInApple()),
                      const SizedBox(height: 10),
                      HolyButton(
                          label: 'Continue with Google',
                          leading: const GoogleMark(),
                          secondary: true,
                          foregroundColor: AppColors.textPrimary,
                          busy:
                              auth.loading && auth.action == AuthAction.google,
                          onPressed: auth.loading
                              ? null
                              : () => ref
                                  .read(authProvider.notifier)
                                  .signInGoogle()),
                      const SizedBox(height: 10),
                      HolyButton(
                          label: 'Continue with email',
                          icon: Icons.mail_outline_rounded,
                          onPressed: auth.loading
                              ? null
                              : () => openScreen(context, const AuthScreen())),
                      TextButton(
                          onPressed: auth.loading
                              ? null
                              : () => openScreen(context, const AuthScreen()),
                          child: const Text('Already have an account? Sign in',
                              textAlign: TextAlign.center,
                              style: HolyTypography.supporting)),
                      if (auth.error != null)
                        InlineMessage(auth.error!, error: true),
                      const LegalFooter(),
                    ])),
                const SizedBox(height: 8),
              ]);
              return SingleChildScrollView(
                  child: ConstrainedBox(
                      constraints: BoxConstraints(minHeight: box.maxHeight),
                      child: content));
            })));
  }
}
