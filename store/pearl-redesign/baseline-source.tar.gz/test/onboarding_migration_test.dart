import 'package:flutter_test/flutter_test.dart';
import 'package:holyher/services/profile_service.dart';

void main() {
  test(
      'legacy preview migrates to real Day 1 without marking onboarding complete',
      () {
    final value = UserProfile.fromJson(
        {'onboardingStep': 6, 'onboardingComplete': false});
    expect(value.onboardingStep, 9);
    expect(value.onboardingComplete, isFalse);
    expect(value.toJson()['onboardingStepId'], 'day-one');
  });
  test('new semantic step version preserves the learning preview', () {
    final value =
        UserProfile.fromJson({'onboardingVersion': 2, 'onboardingStep': 6});
    expect(value.onboardingStep, 6);
    expect(value.toJson()['onboardingStepId'], 'learning-preview');
  });
  test(
      'independent feedback and reading preferences preserve older account defaults',
      () {
    final old = UserProfile.fromJson({});
    expect(old.haptics, isTrue);
    expect(old.sounds, isTrue);
    expect(old.tips, isTrue);
    final muted = UserProfile.fromJson(
        {'sounds': false, 'haptics': true, 'largerText': true});
    expect(muted.sounds, isFalse);
    expect(muted.haptics, isTrue);
    expect(muted.largerText, isTrue);
  });
}
