import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/data/lessons.dart';
import 'package:holyher/features/auth/auth_screen.dart';
import 'package:holyher/features/support/support_screens.dart';
import 'package:holyher/services/auth_service.dart';

class LandingScreen extends ConsumerStatefulWidget {
  const LandingScreen({super.key});
  @override
  ConsumerState<LandingScreen> createState()=>_LandingScreenState();
}
class _LandingScreenState extends ConsumerState<LandingScreen> with WidgetsBindingObserver {
  final _pages=PageController();Timer? _timer;int _page=0;bool _foreground=true;
  static const _titles=['A moment with God.','A path to return to.','Words to carry with you.'];
  @override
  void initState(){super.initState();WidgetsBinding.instance.addObserver(this);}
  @override
  void didChangeDependencies(){super.didChangeDependencies();_schedule();}
  void _schedule(){_timer?.cancel();if(!_foreground||MediaQuery.disableAnimationsOf(context))return;_timer=Timer(const Duration(seconds:5),(){if(mounted&&_pages.hasClients)_pages.animateToPage((_page+1)%3,duration:const Duration(milliseconds:680),curve:Curves.easeInOutCubic);});}
  @override
  void didChangeAppLifecycleState(AppLifecycleState state){_foreground=state==AppLifecycleState.resumed;_schedule();}
  @override
  void dispose(){WidgetsBinding.instance.removeObserver(this);_timer?.cancel();_pages.dispose();super.dispose();}
  void _select(int index){_timer?.cancel();if(MediaQuery.disableAnimationsOf(context)){_pages.jumpToPage(index);}else{_pages.animateToPage(index,duration:const Duration(milliseconds:680),curve:Curves.easeInOutCubic);}}
  @override
  Widget build(BuildContext context){
    final auth=ref.watch(authProvider);
    return HolyScaffold(body:ReadingWidth(maxWidth:620,child:ListView(padding:const EdgeInsets.fromLTRB(24,20,24,24),children:[
      const Row(mainAxisAlignment:MainAxisAlignment.center,children:[HolyMark(size:48),SizedBox(width:12),Text('HolyHer',style:TextStyle(fontSize:25,fontWeight:FontWeight.w600))]),
      const SizedBox(height:24),Text(_titles[_page],textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineMedium),const SizedBox(height:12),
      const Text('365 Bible messages. A little faith, every day.',textAlign:TextAlign.center),const SizedBox(height:24),
      SizedBox(height:MediaQuery.textScalerOf(context).scale(16)>24?520:320,child:NotificationListener<ScrollNotification>(onNotification:(notification){if(notification is ScrollStartNotification)_timer?.cancel();if(notification is ScrollEndNotification)_schedule();return false;},child:PageView(controller:_pages,onPageChanged:(index){setState(()=>_page=index);_schedule();},children:[_scene(0),_scene(1),_scene(2)]))),
      Row(mainAxisAlignment:MainAxisAlignment.center,children:[for(var i=0;i<3;i++)IconButton(tooltip:'Show ${['learning cards','guided roadmap','saved verses'][i]} preview',onPressed:()=>_select(i),icon:Icon(i==_page?Icons.circle:Icons.circle_outlined,size:12,color:AppColors.accent))]),
      const SizedBox(height:12),HolyButton(label:'Continue with Apple',icon:Icons.apple,secondary:true,busy:auth.loading,onPressed:auth.loading?null:()=>ref.read(authProvider.notifier).signInApple()),const SizedBox(height:12),
      HolyButton(label:'Continue with Google',secondary:true,onPressed:auth.loading?null:()=>ref.read(authProvider.notifier).signInGoogle()),const SizedBox(height:12),
      HolyButton(label:'Continue with email',icon:Icons.mail_outline,onPressed:auth.loading?null:()=>openScreen(context,const AuthScreen())),
      TextButton(onPressed:auth.loading?null:()=>openScreen(context,const AuthScreen()),child:const Text('Already have an account? Sign in')),
      if(auth.error!=null)InlineMessage(auth.error!,error:true),const Text('Free enrollment · one additional lesson each calendar day',textAlign:TextAlign.center,style:TextStyle(fontSize:11)),const SizedBox(height:8),const LegalFooter(),
      TextButton(onPressed:()=>openScreen(context,const AboutScreen()),child:const Text('About HolyHer'))
    ])));
  }
  Widget _scene(int index)=>Padding(padding:const EdgeInsets.all(12),child:GlassSurface(highlighted:index!=1,child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Eyebrow('Preview · ${['Learning cards','Guided roadmap','Saved verses'][index]}'),const SizedBox(height:18),
    if(index==0)...[Text(lessons.first.title,style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:16),Text(lessons.first.verseText,style:const TextStyle(fontSize:17,height:1.7)),const SizedBox(height:12),Text(lessons.first.verseReference)]
    else if(index==1)...[const Text('One day at a time.',style:TextStyle(fontSize:22,fontWeight:FontWeight.w500)),for(var i=0;i<3;i++)Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Row(children:[CircleAvatar(backgroundColor:AppColors.surfaceLight,child:Text('${i+1}')),const SizedBox(width:14),Expanded(child:Text(lessons[i].title))])),const Text('Missed lessons remain available.')]
    else ...[const Icon(Icons.bookmark,color:AppColors.accent),const SizedBox(height:12),Text(lessons[2].verseText,style:const TextStyle(fontSize:21,height:1.7)),const SizedBox(height:16),Text(lessons[2].verseReference),const SizedBox(height:16),const Text('Save a lesson to keep its verse close. Search your saved words and share them.')]
  ]))));
}
