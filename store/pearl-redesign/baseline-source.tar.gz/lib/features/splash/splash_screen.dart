import 'package:flutter/material.dart';
import 'package:holyher/core/widgets/holy_loader.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/core/widgets/holy_ui.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});
  @override
  Widget build(BuildContext context) => const HolyScaffold(
      body: Center(
          child: SingleChildScrollView(
              padding: EdgeInsets.all(32),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                HolyMark(size: 108),
                SizedBox(height: 25),
                Text('HolyHer',
                    style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w600,
                        letterSpacing: -1)),
                SizedBox(height: 12),
                Text('A little faith. Every day.',
                    style: TextStyle(color: AppColors.textSecondary)),
                SizedBox(height: 32),
                PulsingDotsLoader(semanticsLabel: 'Opening your journey')
              ]))));
}
