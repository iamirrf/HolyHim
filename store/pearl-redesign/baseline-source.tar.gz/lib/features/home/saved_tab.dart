import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/core/widgets/holy_loader.dart';
import 'package:holyher/data/lessons.dart';
import 'package:holyher/features/lesson/lesson_screen.dart';
import 'package:holyher/services/saved_service.dart';
import 'package:holyher/services/progress_service.dart';

class SavedTab extends ConsumerStatefulWidget {
  final VoidCallback onLearn;
  const SavedTab({super.key, required this.onLearn});
  @override
  ConsumerState<SavedTab> createState() => _SavedTabState();
}

class _SavedTabState extends ConsumerState<SavedTab>
    with AutomaticKeepAliveClientMixin {
  String _query = '', _theme = 'All';
  bool _recent = true;
  @override
  bool get wantKeepAlive => true;
  Future<void> _remove(int day) async {
    try {
      await ref.read(savedProvider.notifier).setSaved(day, false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('Removed from Saved'),
          action: SnackBarAction(
              label: 'Undo',
              onPressed: () =>
                  ref.read(savedProvider.notifier).setSaved(day, true))));
    } catch (_) {
      if (mounted) {
        showNotice(context, 'Your change could not be saved. Please retry.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final saved = ref.watch(savedProvider);
    final rows = lessons
        .where((l) =>
            saved.days.containsKey(l.day) &&
            (_theme == 'All' || l.theme == _theme) &&
            '${l.title} ${l.verseReference} ${l.theme} ${l.day} ${l.verseText}'
                .toLowerCase()
                .contains(_query.toLowerCase()))
        .toList()
      ..sort((a, b) => _recent
          ? saved.days[b.day]!.compareTo(saved.days[a.day]!)
          : a.day.compareTo(b.day));
    final themes = lessons
        .where((l) => saved.days.containsKey(l.day))
        .map((l) => l.theme)
        .toSet()
        .toList()
      ..sort();
    return ReadingWidth(
        maxWidth: 1000,
        child: CustomScrollView(key: const PageStorageKey('saved'), slivers: [
          SliverPadding(
              padding: const EdgeInsets.all(24),
              sliver: SliverToBoxAdapter(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    const PageHeading(
                        eyebrow: 'Words to return to', title: 'Saved lessons.'),
                    const SizedBox(height: 20),
                    TextField(
                        decoration: const InputDecoration(
                            labelText: 'Search saved lessons',
                            prefixIcon: Icon(Icons.search)),
                        onChanged: (v) => setState(() => _query = v)),
                    const SizedBox(height: 12),
                    Wrap(spacing: 12, children: [
                      DropdownButton<String>(
                          value: themes.contains(_theme) ? _theme : 'All',
                          items: [
                            for (final theme in ['All', ...themes])
                              DropdownMenuItem(value: theme, child: Text(theme))
                          ],
                          onChanged: (v) =>
                              setState(() => _theme = v ?? 'All')),
                      TextButton.icon(
                          onPressed: () => setState(() => _recent = !_recent),
                          icon: const Icon(Icons.sort),
                          label: Text(_recent ? 'Recent first' : 'Day order'))
                    ]),
                    if (saved.error != null) InlineMessage(saved.error!),
                    if (saved.error != null || saved.pending.isNotEmpty)
                      TextButton(
                          onPressed: () =>
                              ref.read(savedProvider.notifier).retryLoad(),
                          child: Text(saved.pending.isEmpty
                              ? 'Retry'
                              : '${saved.pending.length} changes pending · Retry')),
                    if (saved.loading)
                      const PulsingDotsLoader(
                          semanticsLabel: 'Loading saved lessons'),
                    if (!saved.loading &&
                        !saved.recoveryRequired &&
                        saved.days.isEmpty) ...[
                      const SizedBox(height: 24),
                      const Text(
                          'Save a verse while learning and it will be waiting here.'),
                      TextButton(
                          onPressed: widget.onLearn,
                          child: const Text('Go to Learn'))
                    ] else if (rows.isEmpty)
                      const Text('No saved lessons match your search.')
                  ]))),
          SliverLayoutBuilder(builder: (context, constraints) {
            final columns = constraints.crossAxisExtent >= 1024
                ? 3
                : constraints.crossAxisExtent >= 700
                    ? 2
                    : 1;
            // Natural-height rows preserve large text rather than forcing an aspect ratio.
            return SliverList.builder(
                itemCount: (rows.length / columns).ceil(),
                itemBuilder: (context, index) => Padding(
                    padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
                    child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          for (var col = 0; col < columns; col++)
                            Expanded(
                                child: index * columns + col < rows.length
                                    ? Padding(
                                        padding: EdgeInsets.only(
                                            right: col < columns - 1 ? 12 : 0),
                                        child:
                                            _row(rows[index * columns + col]))
                                    : const SizedBox())
                        ])));
          }),
          const SliverToBoxAdapter(child: SizedBox(height: 24))
        ]));
  }

  Widget _row(DailyLesson lesson) => GlassSurface(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Eyebrow('Day ${lesson.day} · ${lesson.theme}'),
        const SizedBox(height: 14),
        Text(lesson.verseText,
            style: const TextStyle(fontSize: 17, height: 1.7)),
        const SizedBox(height: 12),
        Text('${lesson.verseReference} · World English Bible'),
        const SizedBox(height: 12),
        Text(lesson.title, style: Theme.of(context).textTheme.titleMedium),
        Wrap(children: [
          TextButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => LessonScreen(lesson: lesson))),
              child: const Text('Open lesson')),
          Builder(
              builder: (shareContext) => IconButton(
                  tooltip: 'Share verse',
                  icon: const Icon(Icons.ios_share),
                  onPressed: () {
                    final box = shareContext.findRenderObject() as RenderBox?;
                    SharePlus.instance.share(ShareParams(
                        text:
                            '${lesson.verseText}\n${lesson.verseReference}\nWorld English Bible (WEB)\nHolyHer · ${lesson.title}',
                        sharePositionOrigin: box == null
                            ? null
                            : box.localToGlobal(Offset.zero) & box.size));
                  })),
          IconButton(
              tooltip: 'Remove saved lesson',
              onPressed: () => _remove(lesson.day),
              icon: const Icon(Icons.bookmark_remove_outlined))
        ]),
        if (!ref.watch(progressProvider).isUnlocked(lesson.day))
          const Text('This lesson opens on its calendar day.')
      ]));
}

class SaveLessonButton extends ConsumerWidget {
  final int day;
  const SaveLessonButton({super.key, required this.day});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final saved = ref.watch(savedProvider).days.containsKey(day);
    return IconButton(
        tooltip: saved ? 'Remove saved lesson' : 'Save lesson',
        isSelected: saved,
        icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border),
        onPressed: () async {
          try {
            await ref.read(savedProvider.notifier).setSaved(day, !saved);
          } catch (_) {
            if (context.mounted) {
              showNotice(context,
                  'Your saved change could not be stored. Please retry.');
            }
          }
        });
  }
}
