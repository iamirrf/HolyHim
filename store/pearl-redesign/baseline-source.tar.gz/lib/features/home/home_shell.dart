import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/core/widgets/holy_ui.dart';
import 'package:holyher/data/lessons.dart';
import 'package:holyher/features/lesson/lesson_screen.dart';
import 'package:holyher/features/onboarding/personalization.dart';
import 'package:holyher/features/settings/settings_screen.dart';
import 'package:holyher/features/support/support_screens.dart';
import 'package:holyher/services/auth_service.dart';
import 'package:holyher/services/profile_service.dart';
import 'package:holyher/services/progress_service.dart';
import 'package:holyher/services/streak_service.dart';

import 'package:holyher/data/units.dart';
import 'package:holyher/features/home/saved_tab.dart';
import 'package:holyher/core/widgets/holy_header.dart';

class HomeShell extends ConsumerStatefulWidget {
  const HomeShell({super.key});
  @override
  ConsumerState<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends ConsumerState<HomeShell> {
  final _pager = PageController();
  int _index = 0;
  bool _compact = false;
  double _down = 0;
  final _scrolls = List.generate(3, (_) => ScrollController());
  @override
  void dispose() {
    _pager.dispose();
    for (final scroll in _scrolls) {
      scroll.dispose();
    }
    super.dispose();
  }

  void _select(int index) {
    if (index == _index) {
      final scroll = _scrolls[index];
      if (scroll.hasClients) {
        scroll.animateTo(0,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOutCubic);
      }
    }
    setState(() => _compact = false);
    if(MediaQuery.disableAnimationsOf(context)) {
      _pager.jumpToPage(index);
    } else {
      _pager.animateToPage(index,duration:const Duration(milliseconds:300),curve:Curves.easeOutCubic);
    }
  }

  bool _onScroll(ScrollNotification n) {
    if (n.depth != 0 || n.metrics.axis != Axis.vertical) return false;
    if (n is ScrollUpdateNotification &&
        n.dragDetails != null &&
        n.metrics.pixels >= 0 &&
        n.metrics.pixels <= n.metrics.maxScrollExtent) {
      final delta = n.scrollDelta ?? 0;
      if (delta < 0 || n.metrics.pixels < 24) {
        _down = 0;
        if (_compact) setState(() => _compact = false);
      } else {
        _down += delta;
        if (_down >= 24 && !_compact) setState(() => _compact = true);
      }
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final accessible = MediaQuery.accessibleNavigationOf(context) ||
        MediaQuery.textScalerOf(context).scale(14) > 20;
    return HolyScaffold(
        body: Column(children: [
          HolyHeader(onProgress: () => _showProgress(context, ref)),
          Expanded(
              child: NotificationListener<ScrollNotification>(
                  onNotification: _onScroll,
                  child: PageView(
                      controller: _pager,
                      onPageChanged: (index) => setState(() {
                            _index = index;
                            _compact = false;
                            _down = 0;
                          }),
                      children: [
                        PrimaryScrollController(
                            controller: _scrolls[0], child: const _LearnTab()),
                        PrimaryScrollController(
                            controller: _scrolls[1],
                            child: SavedTab(onLearn: () => _select(0))),
                        PrimaryScrollController(
                            controller: _scrolls[2], child: const _ProfileTab())
                      ])))
        ]),
        bottomNavigationBar: SafeArea(
            top: false,
            child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                child: ReadingWidth(
                    maxWidth: 520,
                    child: GlassSurface(
                        padding: const EdgeInsets.all(6),
                        child: Row(children: [
                          for (final tab in [
                            (0, Icons.route_outlined, 'Learn'),
                            (1, Icons.bookmark_border, 'Saved'),
                            (2, Icons.person_outline, 'Profile')
                          ])
                            Expanded(
                                child: HolyPressable(
                                    label: tab.$3,
                                    selected: _index == tab.$1,
                                    onPressed: () => _select(tab.$1),
                                    child: AnimatedContainer(
                                        duration:
                                            const Duration(milliseconds: 220),
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 10, horizontal: 4),
                                        decoration: BoxDecoration(
                                            color: _index == tab.$1
                                                ? AppColors.surfaceLight
                                                : Colors.transparent,
                                            borderRadius:
                                                BorderRadius.circular(24)),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(tab.$2,
                                                  color: AppColors.accent),
                                              if (!_compact || accessible) ...[
                                                const SizedBox(height: 4),
                                                Text(tab.$3,
                                                    style: const TextStyle(
                                                        fontSize: 11))
                                              ]
                                            ]))))
                        ]))))));
  }
}

void _openLesson(BuildContext context, DailyLesson lesson) =>
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => LessonScreen(lesson: lesson)));
void _showProgress(BuildContext context, WidgetRef ref) {
  final progress = ref.read(progressProvider),
      streak = ref.read(streakProvider);
  showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => SafeArea(
          child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Your journey',
                        style: Theme.of(context).textTheme.headlineMedium),
                    const SizedBox(height: 16),
                    Text(
                        '${progress.completedCount} of 365 lessons complete · ${streak.current} day streak'),
                    const SizedBox(height: 16),
                    Text(
                        'Activity dates in ${progress.timeZone ?? 'your journey timezone'}'),
                    const SizedBox(height: 12),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      for (final day in streak.activeDays.toList()..sort())
                        Chip(label: Text(day))
                    ]),
                    const SizedBox(height: 16),
                    Text('Milestones: ${[
                      7,
                      30,
                      90,
                      180,
                      365
                    ].where((n) => progress.completedCount >= n).join(', ')}')
                  ]))));
}

class _LearnTab extends ConsumerStatefulWidget {
  const _LearnTab();
  @override
  ConsumerState<_LearnTab> createState() => _LearnTabState();
}

class _LearnTabState extends ConsumerState<_LearnTab>
    with AutomaticKeepAliveClientMixin {
  String _query = '';
  bool _list = false;
  @override
  bool get wantKeepAlive => true;
  void _preview(DailyLesson lesson) {
    final progress = ref.read(progressProvider);
    if (progress.isUnlocked(lesson.day)) {
      _openLesson(context, lesson);
      return;
    }
    showModalBottomSheet(
        context: context,
        showDragHandle: true,
        builder: (context) => SafeArea(
            child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Day ${lesson.day} · ${lesson.title}',
                          style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 16),
                      Text(
                          'One additional lesson unlocks each calendar day in ${progress.timeZone ?? 'your journey timezone'}. Completion of earlier lessons does not affect availability. Reconnect to confirm new daily unlocks.')
                    ]))));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final profile = ref.watch(profileProvider),
        progress = ref.watch(progressProvider);
    final next = progress.nextLesson;
    final matches = lessons
        .where((l) => '${l.day} ${l.title} ${l.verseReference} ${l.theme}'
            .toLowerCase()
            .contains(_query.toLowerCase()))
        .toList();
    return ReadingWidth(
        maxWidth: 800,
        child: RefreshIndicator(
            onRefresh: () => ref.read(progressProvider.notifier).refresh(),
            child:
                CustomScrollView(key: const PageStorageKey('learn'), slivers: [
              SliverPadding(
                  padding: const EdgeInsets.all(24),
                  sliver: SliverToBoxAdapter(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                        PageHeading(
                            eyebrow: profile.name.isEmpty
                                ? 'A little faith, every day'
                                : 'Welcome, ${profile.name}',
                            title: 'One step at a time.',
                            subtitle:
                                'Your ordered journey through 365 Bible messages.'),
                        const SizedBox(height: 24),
                        GlassSurface(
                            highlighted: true,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(children: [
                                    SizedBox(
                                        width: 64,
                                        height: 64,
                                        child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              SizedBox.expand(
                                                  child: CircularProgressIndicator(
                                                      value: progress.fraction,
                                                      strokeWidth: 6,
                                                      backgroundColor:
                                                          AppColors.divider,
                                                      semanticsLabel:
                                                          'Journey completion')),
                                              Text('${progress.completedCount}',
                                                  style: const TextStyle(
                                                      fontSize: 20))
                                            ])),
                                    const SizedBox(width: 20),
                                    Expanded(
                                        child: Text(
                                            '${progress.completedCount} of 365 complete',
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleLarge))
                                  ]),
                                  const SizedBox(height: 20),
                                  if (next != null) ...[
                                    Eyebrow('Next · Day ${next.day}'),
                                    const SizedBox(height: 10),
                                    Text(next.title,
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleLarge),
                                    const SizedBox(height: 12),
                                    HolyButton(
                                        label: 'Continue learning',
                                        onPressed: () =>
                                            _openLesson(context, next)),
                                    const SizedBox(height: 12),
                                    const Text(
                                        'Missed days stay available. Learn at a pace that fits today.')
                                  ] else
                                    Text(progress.allComplete
                                        ? 'All 365 lessons completed. Your year is here to revisit.'
                                        : progress.unlockedThrough == 365
                                            ? 'All 365 lessons are available.'
                                            : 'You’re caught up. Your next lesson opens on the next calendar day in ${progress.timeZone ?? 'your journey timezone'}.'),
                                ])),
                        if (progress.syncError != null) ...[
                          const SizedBox(height: 14),
                          InlineMessage(progress.syncError!),
                          TextButton(
                              onPressed: () =>
                                  ref.read(progressProvider.notifier).refresh(),
                              child: const Text('Retry connection'))
                        ],
                        const SizedBox(height: 24),
                        TextField(
                            decoration: const InputDecoration(
                                labelText:
                                    'Search day, title, reference, or theme',
                                prefixIcon: Icon(Icons.search)),
                            onChanged: (value) =>
                                setState(() => _query = value)),
                        const SizedBox(height: 12),
                        TextButton.icon(
                            onPressed: () => setState(() => _list = !_list),
                            icon: Icon(_list ? Icons.route : Icons.list),
                            label: Text(_list
                                ? 'Show roadmap'
                                : 'All lessons · accessible list')),
                        if (matches.isEmpty)
                          const Text('No lessons match your search.')
                      ]))),
              if (_list || _query.isNotEmpty)
                SliverList.builder(
                    itemCount: matches.length,
                    itemBuilder: (context, index) {
                      final lesson = matches[index];
                      return Padding(
                          padding: const EdgeInsets.fromLTRB(24, 0, 24, 12),
                          child: MenuRow(
                              title: 'Day ${lesson.day} · ${lesson.title}',
                              subtitle:
                                  '${lesson.verseReference} · ${lesson.theme} · ${progress.completedDays.contains(lesson.day) ? 'Completed' : progress.isUnlocked(lesson.day) ? 'Available' : 'Future'}',
                              icon: progress.completedDays.contains(lesson.day)
                                  ? Icons.check_circle
                                  : progress.isUnlocked(lesson.day)
                                      ? Icons.menu_book
                                      : Icons.lock_outline,
                              onTap: () => _preview(lesson)));
                    })
              else
                SliverList.builder(
                    itemCount: 73,
                    itemBuilder: (context, index) => Padding(
                        padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
                        child: Column(children: [
                          HolyPressable(
                              onPressed: () => _unit(index),
                              child: GlassSurface(
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                    Eyebrow(
                                        'Unit ${index + 1} · Days ${index * 5 + 1}–${index * 5 + 5}'),
                                    const SizedBox(height: 10),
                                    Text(unitTitles[index],
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleLarge),
                                    const SizedBox(height: 8),
                                    Text(
                                        '${List.generate(5, (i) => index * 5 + i + 1).where(progress.completedDays.contains).length} of 5 complete')
                                  ]))),
                          for (var node = 0; node < 5; node++)
                            Align(
                                alignment: Alignment(
                                    math.sin(node * math.pi / 2) * .65, 0),
                                child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 10),
                                    child: _node(lessons[index * 5 + node],
                                        progress, next?.day)))
                        ]))),
              const SliverToBoxAdapter(child: SizedBox(height: 24))
            ])));
  }

  Widget _node(DailyLesson lesson, ProgressState progress, int? recommended) {
    final done = progress.completedDays.contains(lesson.day),
        available = progress.isUnlocked(lesson.day);
    return SizedBox(
        width: 240,
        child: HolyPressable(
            label:
                'Day ${lesson.day}, ${lesson.title}, ${done ? 'completed' : available ? 'available' : 'future'}',
            onPressed: () => _preview(lesson),
            child: Column(children: [
              Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: done ? AppColors.accent : Colors.white,
                      border: Border.all(
                          color: AppColors.accent,
                          width: recommended == lesson.day ? 3 : 1),
                      boxShadow: recommended == lesson.day
                          ? [
                              BoxShadow(
                                  color: AppColors.accent.withValues(alpha: .2),
                                  blurRadius: 22)
                            ]
                          : null),
                  child: Icon(
                      done
                          ? Icons.check
                          : available
                              ? Icons.menu_book
                              : Icons.lock_outline,
                      color: done ? Colors.white : AppColors.accent)),
              const SizedBox(height: 8),
              Text('Day ${lesson.day} · ${lesson.title}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13)),
              if (recommended == lesson.day)
                const Text('Recommended next',
                    style: TextStyle(fontSize: 11, color: AppColors.accent))
            ])));
  }

  void _unit(int index) {
    final rows = lessons.sublist(index * 5, index * 5 + 5);
    showModalBottomSheet(
        context: context,
        showDragHandle: true,
        isScrollControlled: true,
        builder: (context) => SafeArea(
            child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(unitTitles[index],
                          style: Theme.of(context).textTheme.headlineMedium),
                      const SizedBox(height: 16),
                      Text(
                          'Days ${index * 5 + 1}–${index * 5 + 5}. Read the passages below and explore their meaning in everyday life.'),
                      for (final lesson in rows)
                        ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text('Day ${lesson.day} · ${lesson.title}'),
                            subtitle: Text(lesson.verseReference),
                            onTap: () {
                              Navigator.pop(context);
                              _preview(lesson);
                            })
                    ]))));
  }
}

class _Chip extends StatelessWidget {
  final String text;
  final IconData icon;
  const _Chip({required this.text, required this.icon});
  @override
  Widget build(BuildContext context) => Wrap(
          spacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            Icon(icon, size: 18, color: AppColors.accent),
            Text(text, style: const TextStyle(fontSize: 12))
          ]);
}

class _ProfileTab extends ConsumerWidget {
  const _ProfileTab();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider).user;
    final profile = ref.watch(profileProvider);
    final progress = ref.watch(progressProvider);
    final streak = ref.watch(streakProvider);
    final syncing = progress.pendingDays.isNotEmpty;
    return ReadingWidth(
        child: ListView(
            key: const PageStorageKey('profile'),
            padding: const EdgeInsets.fromLTRB(26, 24, 26, 28),
            children: [
          const SizedBox.shrink(),
          const SizedBox(height: 28),
          GlassSurface(
              highlighted: true,
              padding: const EdgeInsets.all(26),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const HolyMark(size: 68),
                    const SizedBox(height: 22),
                    const Eyebrow('A little faith, every day'),
                    const SizedBox(height: 11),
                    Text(
                        profile.name.isEmpty
                            ? 'Your quiet space.'
                            : '${profile.name}’s\nquiet space.',
                        style: Theme.of(context).textTheme.headlineMedium),
                    const SizedBox(height: 14),
                    Text(user?.email ?? 'Your HolyHer account',
                        style: const TextStyle(
                            fontSize: 12, color: AppColors.textSecondary)),
                    const SizedBox(height: 22),
                    const _Chip(
                        text: 'HolyHer 365 edition',
                        icon: Icons.verified_outlined)
                  ])),
          const SectionLabel('Your journey'),
          GlassSurface(
              child: Column(children: [
            _stat('Messages completed',
                '${progress.completedCount} / ${lessons.length}'),
            const Divider(height: 28),
            _stat('Current rhythm', '${streak.current} days'),
            const Divider(height: 28),
            _stat('Longest rhythm', '${streak.longest} days')
          ])),
          const SizedBox(height: 12),
          MenuRow(
              title: progress.syncError != null
                  ? 'Using your saved journey'
                  : syncing
                      ? 'Saved on this device'
                      : 'Your progress is saved',
              subtitle: progress.syncError != null && !syncing
                  ? 'Reconnect to check new daily lessons and sync your journey. Tap to retry.'
                  : syncing
                      ? 'Reconnect to sync ${progress.pendingDays.length} completed message${progress.pendingDays.length == 1 ? '' : 's'}. Tap to retry.'
                      : 'Your account keeps your journey with you.',
              icon: progress.syncError != null || syncing
                  ? Icons.cloud_upload_outlined
                  : Icons.cloud_done_outlined,
              onTap: progress.syncError != null || syncing
                  ? () => ref.read(progressProvider.notifier).refresh()
                  : null),
          const SectionLabel('Your rhythm'),
          MenuRow(
              title: 'Your focus',
              subtitle: focusLabel(profile.focus),
              icon: Icons.spa_outlined,
              onTap: () => openScreen(context, const SettingsScreen())),
          MenuRow(
              title: 'Settings',
              subtitle: 'Your account, reminders, and preferences',
              icon: Icons.tune_rounded,
              onTap: () => openScreen(context, const SettingsScreen())),
          const SectionLabel('Here for you'),
          MenuRow(
              title: 'Help & support',
              icon: Icons.help_outline_rounded,
              onTap: () => openScreen(context, const HelpScreen())),
          MenuRow(
              title: 'About HolyHer',
              icon: Icons.info_outline_rounded,
              onTap: () => openScreen(context, const AboutScreen())),
          const LegalFooter(),
        ]));
  }

  Widget _stat(String label, String value) => Row(children: [
        Expanded(
            child: Text(label,
                style: const TextStyle(
                    fontSize: 13, color: AppColors.textSecondary))),
        const SizedBox(width: 16),
        Flexible(
            child: Text(value,
                textAlign: TextAlign.right,
                style:
                    const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)))
      ]);
}
