/// Product identity for the free HolyHer 365 edition.
abstract final class AppConstants {
  static const appName = 'HolyHer';
  static const tagline = 'A little faith. A little courage. Every day.';
  static const totalDays = 365;
  static const websiteUrl = 'https://holyher-app-production.web.app';
  static const privacyUrl = '$websiteUrl/privacy';
  static const termsUrl = '$websiteUrl/terms';
  static const supportUrl = '$websiteUrl/support';
  static const supportEmail = String.fromEnvironment('HOLYHER_SUPPORT_EMAIL');
}
