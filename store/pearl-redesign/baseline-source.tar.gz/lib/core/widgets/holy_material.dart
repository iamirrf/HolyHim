import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:holyher/core/theme/app_theme.dart';
import 'package:holyher/services/accessibility_service.dart';

class HolyFadingMaterial extends ConsumerWidget {
  final Widget child;
  const HolyFadingMaterial({super.key,required this.child});
  @override
  Widget build(BuildContext context,WidgetRef ref){
    final opaque=ref.watch(reduceTransparencyProvider);
    return ClipRect(child:BackdropFilter(filter:ImageFilter.blur(sigmaX:20,sigmaY:20),enabled:!opaque,child:DecoratedBox(decoration:BoxDecoration(color:opaque?Colors.white:null,gradient:opaque?null:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[for(final opacity in [.70,.58,.38,.16,0.0])AppColors.background.withValues(alpha:opacity)],stops:const [0,.30,.60,.82,1])),child:child)));
  }
}
